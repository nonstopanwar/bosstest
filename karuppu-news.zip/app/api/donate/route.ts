import { NextResponse } from "next/server"
import nodemailer from "nodemailer"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, phone, amount, message, paymentId } = body

    // Validate form data
    if (!name || !email || !amount) {
      return NextResponse.json({ success: false, message: "அனைத்து அவசியமான புலங்களையும் நிரப்பவும்" }, { status: 400 })
    }

    // Create email transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "hello@karuppu.in",
        pass: process.env.EMAIL_PASSWORD || "app_password_here",
      },
    })

    // Email content
    const mailOptions = {
      from: "hello@karuppu.in",
      to: "hello@karuppu.in",
      replyTo: email,
      subject: `புதிய நன்கொடை: ₹${amount} - ${name}`,
      html: `
        <h2>கருப்பு எழுத்துக் கழகம் - நன்கொடை விவரங்கள்</h2>
        <p><strong>பெயர்:</strong> ${name}</p>
        <p><strong>மின்னஞ்சல்:</strong> ${email}</p>
        <p><strong>தொலைபேசி:</strong> ${phone || "குறிப்பிடப்படவில்லை"}</p>
        <p><strong>நன்கொடை தொகை:</strong> ₹${amount}</p>
        <p><strong>பணப்பரிமாற்ற ஐடி:</strong> ${paymentId || "குறிப்பிடப்படவில்லை"}</p>
        ${message ? `<p><strong>செய்தி:</strong></p><p>${message.replace(/\n/g, "<br>")}</p>` : ""}
        <p>இந்த மின்னஞ்சல் karuppu.in இணையதளத்தின் நன்கொடை படிவத்தில் இருந்து அனுப்பப்பட்டது.</p>
      `,
    }

    // Save to database (placeholder)
    // const savedDonation = await db.donations.create({
    //   data: {
    //     name,
    //     email,
    //     phone,
    //     amount: parseFloat(amount),
    //     message,
    //     paymentId,
    //     createdAt: new Date()
    //   }
    // })

    // Send email (commented out for development)
    /*
    await transporter.sendMail(mailOptions)
    */

    // Send thank you email to donor
    const thankYouMailOptions = {
      from: "hello@karuppu.in",
      to: email,
      subject: "உங்கள் நன்கொடைக்கு நன்றி - கருப்பு எழுத்துக் கழகம்",
      html: `
    <h2>உங்கள் நன்கொடைக்கு நன்றி!</h2>
    <p>அன்புள்ள ${name},</p>
    <p>கருப்பு எழுத்துக் கழகத்திற்கு ₹${amount} நன்கொடை அளித்ததற்கு நன்றி. உங்கள் ஆதரவு எங்கள் செயல்பாடுகளுக்கு மிகவும் உதவியாக இருக்கும்.</p>
    <p>உங்கள் நன்கொடை விவரங்கள்:</p>
    <ul>
      <li>நன்கொடை தொகை: ₹${amount}</li>
      <li>தேதி: ${new Date().toLocaleDateString()}</li>
      ${paymentId ? `<li>பணப்பரிமாற்ற ஐடி: ${paymentId}</li>` : ""}
    </ul>
    <p>மீண்டும் ஒருமுறை உங்கள் ஆதரவுக்கு நன்றி.</p>
    <p>அன்புடன்,<br>கருப்பு எழுத்துக் கழகம் குழு</p>
  `,
    }

    // Send thank you email (commented out for development)
    /*
    await transporter.sendMail(thankYouMailOptions)
    */

    return NextResponse.json(
      {
        success: true,
        message: "நன்கொடை வெற்றிகரமாக பதிவு செய்யப்பட்டது. உங்கள் ஆதரவுக்கு நன்றி!",
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Donation submission error:", error)
    return NextResponse.json(
      { success: false, message: "நன்கொடை பதிவில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்." },
      { status: 500 },
    )
  }
}
