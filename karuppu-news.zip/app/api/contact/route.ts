import { NextResponse } from "next/server"
import nodemailer from "nodemailer"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, subject, message } = body

    // Validate form data
    if (!name || !email || !subject || !message) {
      return NextResponse.json({ success: false, message: "அனைத்து புலங்களையும் நிரப்பவும்" }, { status: 400 })
    }

    // Create email transporter
    // Note: In production, use environment variables for these credentials
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "hello@karuppu.in", // Changed from karuppuezhutthu@gmail.com
        pass: process.env.EMAIL_PASSWORD || "app_password_here", // Use app password for Gmail
      },
    })

    // Email content
    const mailOptions = {
      from: "hello@karuppu.in",
      to: "hello@karuppu.in",
      replyTo: email,
      subject: `தொடர்பு படிவம்: ${subject}`,
      html: `
        <h2>கருப்பு எழுத்துக் கழகம் - தொடர்பு படிவம்</h2>
        <p><strong>பெயர்:</strong> ${name}</p>
        <p><strong>மின்னஞ்சல்:</strong> ${email}</p>
        <p><strong>தலைப்பு:</strong> ${subject}</p>
        <p><strong>செய்தி:</strong></p>
        <p>${message.replace(/\n/g, "<br>")}</p>
        <p>இந்த மின்னஞ்சல் karuppu.in இணையதளத்தின் தொடர்பு படிவத்தில் இருந்து அனுப்பப்பட்டது.</p>
      `,
    }

    // Save to database (placeholder - implement with your database)
    // In a real implementation, you would save this data to your database
    // const savedContact = await db.contacts.create({
    //   data: { name, email, subject, message, createdAt: new Date() }
    // })

    // Send email
    // In development/testing, we'll just simulate success
    // In production, uncomment the following code:
    /*
    await transporter.sendMail(mailOptions)
    */

    // Return success response
    return NextResponse.json(
      {
        success: true,
        message: "உங்கள் செய்தி வெற்றிகரமாக அனுப்பப்பட்டது. விரைவில் உங்களை தொடர்பு கொள்வோம்.",
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Contact form submission error:", error)
    return NextResponse.json(
      { success: false, message: "செய்தி அனுப்புவதில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்." },
      { status: 500 },
    )
  }
}
