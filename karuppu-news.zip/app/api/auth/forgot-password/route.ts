import { NextResponse } from "next/server"
import nodemailer from "nodemailer"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email } = body

    // Validate email
    if (!email) {
      return NextResponse.json({ success: false, message: "மின்னஞ்சல் முகவரி தேவை" }, { status: 400 })
    }

    // In a real app, you would:
    // 1. Check if the email exists in your database
    // 2. Generate a unique token and store it with an expiration time
    // 3. Send an email with a reset link containing the token

    // Create a reset token (in a real app, this would be stored in a database)
    const resetToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
    const resetLink = `https://karuppu.in/reset-password?token=${resetToken}&email=${encodeURIComponent(email)}`

    // Create email transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "hello@karuppu.in",
        pass: process.env.EMAIL_PASSWORD || "app_password_here",
      },
    })

    // Email content
    const mailOptions = {
      from: "hello@karuppu.in",
      to: email,
      subject: "கருப்பு எழுத்துக் கழகம் - கடவுச்சொல் மீட்டமைப்பு கோரிக்கை",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #e10000; padding: 20px; text-align: center; color: white;">
            <h1>கருப்பு எழுத்துக் கழகம்</h1>
          </div>
          <div style="padding: 20px; border: 1px solid #ddd; border-top: none;">
            <h2>கடவுச்சொல் மீட்டமைப்பு கோரிக்கை</h2>
            <p>வணக்கம்,</p>
            <p>உங்கள் கணக்கிற்கான கடவுச்சொல் மீட்டமைப்பு கோரிக்கை பெறப்பட்டது. உங்கள் கடவுச்சொல்லை மீட்டமைக்க கீழே உள்ள பொத்தானைக் கிளிக் செய்யவும்:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetLink}" style="background-color: #e10000; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold;">கடவுச்சொல்லை மீட்டமைக்க</a>
            </div>
            <p>இந்த இணைப்பு 24 மணி நேரத்திற்கு மட்டுமே செல்லுபடியாகும்.</p>
            <p>நீங்கள் இந்த கோரிக்கையை செய்யவில்லை என்றால், இந்த மின்னஞ்சலை புறக்கணிக்கவும்.</p>
            <p>நன்றி,<br>கருப்பு எழுத்துக் கழகம் குழு</p>
          </div>
          <div style="background-color: #f5f5f5; padding: 15px; text-align: center; font-size: 12px; color: #666;">
            <p>© ${new Date().getFullYear()} கருப்பு எழுத்துக் கழகம். அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.</p>
          </div>
        </div>
      `,
    }

    // Send email (commented out for development)
    /*
    await transporter.sendMail(mailOptions)
    */

    // For demonstration purposes, log the reset link
    console.log("Reset link:", resetLink)

    return NextResponse.json(
      {
        success: true,
        message: "கடவுச்சொல் மீட்டமைப்பு இணைப்பு அனுப்பப்பட்டது. உங்கள் மின்னஞ்சலைச் சரிபார்க்கவும்.",
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Forgot password error:", error)
    return NextResponse.json(
      { success: false, message: "கடவுச்சொல் மீட்டமைப்பு கோரிக்கையில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்." },
      { status: 500 },
    )
  }
}
