import { NextResponse } from "next/server"
import nodemailer from "nodemailer"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, phone, district, password, userType, address, experience } = body

    // Validate form data
    if (!name || !email || !phone || !district || !password) {
      return NextResponse.json({ success: false, message: "அனைத்து அவசியமான புலங்களையும் நிரப்பவும்" }, { status: 400 })
    }

    // Create email transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "hello@karuppu.in",
        pass: process.env.EMAIL_PASSWORD || "app_password_here",
      },
    })

    // Email content for admin notification
    const adminMailOptions = {
      from: "hello@karuppu.in",
      to: "hello@karuppu.in",
      subject: `புதிய ${userType === "reporter" ? "செய்தியாளர்" : "மாவட்ட அமைப்பாளர்"} பதிவு - ${name}`,
      html: `
        <h2>கருப்பு எழுத்துக் கழகம் - புதிய பயனர் பதிவு</h2>
        <p><strong>பெயர்:</strong> ${name}</p>
        <p><strong>மின்னஞ்சல்:</strong> ${email}</p>
        <p><strong>தொலைபேசி:</strong> ${phone}</p>
        <p><strong>மாவட்டம்:</strong> ${district}</p>
        <p><strong>பயனர் வகை:</strong> ${userType === "reporter" ? "செய்தியாளர்" : "மாவட்ட அமைப்பாளர்"}</p>
        <p><strong>முகவரி:</strong> ${address || "குறிப்பிடப்படவில்லை"}</p>
        ${experience ? `<p><strong>அனுபவம்:</strong> ${experience}</p>` : ""}
        <p>இந்த பயனர் e-KYC சரிபார்ப்பை நிறைவு செய்ய வேண்டும்.</p>
      `,
    }

    // Email content for user welcome
    const userMailOptions = {
      from: "hello@karuppu.in",
      to: email,
      subject: "கருப்பு எழுத்துக் கழகத்தில் வரவேற்கிறோம்!",
      html: `
        <h2>கருப்பு எழுத்துக் கழகத்தில் வரவேற்கிறோம்!</h2>
        <p>அன்புள்ள ${name},</p>
        <p>கருப்பு எழுத்துக் கழகத்தில் ${userType === "reporter" ? "செய்தியாளராக" : "மாவட்ட அமைப்பாளராக"} பதிவு செய்ததற்கு நன்றி.</p>
        <p>உங்கள் கணக்கை முழுமையாக செயல்படுத்த, e-KYC சரிபார்ப்பை நிறைவு செய்ய வேண்டும். இதற்கு கீழே உள்ள இணைப்பைக் கிளிக் செய்யவும்:</p>
        <p><a href="https://karuppu.in/kyc" style="background-color: #e10000; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">e-KYC சரிபார்ப்பை நிறைவு செய்ய</a></p>
        <p>உங்கள் கணக்கு விவரங்கள்:</p>
        <ul>
          <li>பயனர்பெயர்: ${email}</li>
          <li>பயனர் வகை: ${userType === "reporter" ? "செய்தியாளர்" : "மாவட்ட அமைப்பாளர்"}</li>
          <li>மாவட்டம்: ${district}</li>
        </ul>
        <p>ஏதேனும் கேள்விகள் இருந்தால், contact@karuppu.in என்ற மின்னஞ்சல் முகவரிக்கு எழுதவும்.</p>
        <p>அன்புடன்,<br>கருப்பு எழுத்துக் கழகம் குழு</p>
      `,
    }

    // Save to database (placeholder)
    // const hashedPassword = await bcrypt.hash(password, 10);
    // const savedUser = await db.users.create({
    //   data: {
    //     name,
    //     email,
    //     phone,
    //     district,
    //     password: hashedPassword,
    //     userType,
    //     address,
    //     experience,
    //     kycStatus: 'pending',
    //     createdAt: new Date()
    //   }
    // })

    // Send emails (commented out for development)
    /*
    await transporter.sendMail(adminMailOptions)
    await transporter.sendMail(userMailOptions)
    */

    // Generate a user ID (in production, this would come from the database)
    const userId = "user_" + Math.floor(Math.random() * 10000)

    return NextResponse.json(
      {
        success: true,
        message: "பதிவு வெற்றிகரமாக முடிந்தது. e-KYC சரிபார்ப்பை நிறைவு செய்யவும்.",
        userId,
        redirectTo: "/kyc",
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json(
      { success: false, message: "பதிவு செய்வதில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்." },
      { status: 500 },
    )
  }
}
