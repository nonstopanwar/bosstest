import { NextResponse } from "next/server"
import nodemailer from "nodemailer"

export async function POST(request: Request) {
  try {
    // In a real implementation, you would handle file uploads
    // For this example, we'll assume form data is sent as JSON
    const body = await request.json()
    const { aadhaar, pan, dob, gender, userId } = body

    // Validate form data
    if (!aadhaar || !pan || !dob) {
      return NextResponse.json({ success: false, message: "அனைத்து அவசியமான புலங்களையும் நிரப்பவும்" }, { status: 400 })
    }

    // Create email transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "hello@karuppu.in",
        pass: process.env.EMAIL_PASSWORD || "app_password_here",
      },
    })

    // Email content for admin notification
    const adminMailOptions = {
      from: "hello@karuppu.in",
      to: "hello@karuppu.in",
      subject: `புதிய e-KYC சமர்ப்பிப்பு - பயனர் ID: ${userId || "Unknown"}`,
      html: `
        <h2>கருப்பு எழுத்துக் கழகம் - புதிய e-KYC சமர்ப்பிப்பு</h2>
        <p><strong>பயனர் ID:</strong> ${userId || "Unknown"}</p>
        <p><strong>ஆதார் எண்:</strong> ${aadhaar.substring(0, 4)}XXXX${aadhaar.substring(8)}</p>
        <p><strong>பான் கார்டு எண்:</strong> ${pan.substring(0, 2)}XXXXX${pan.substring(7)}</p>
        <p><strong>பிறந்த தேதி:</strong> ${dob}</p>
        <p><strong>பாலினம்:</strong> ${gender}</p>
        <p><strong>சமர்ப்பிக்கப்பட்ட தேதி:</strong> ${new Date().toLocaleString()}</p>
        <p>இந்த பயனரின் e-KYC ஆவணங்களை சரிபார்க்கவும்.</p>
      `,
    }

    // Save to database (placeholder)
    // const kycSubmission = await db.kyc.create({
    //   data: {
    //     userId,
    //     aadhaarNumber: aadhaar,
    //     panNumber: pan,
    //     dateOfBirth: new Date(dob),
    //     gender,
    //     status: 'pending',
    //     submittedAt: new Date()
    //   }
    // })

    // Generate a KYC ID (in production, this would come from the database)
    const kycId = "KYC" + Math.floor(Math.random() * 10000000)

    // Send email (commented out for development)
    /*
    await transporter.sendMail(adminMailOptions)
    */

    return NextResponse.json(
      {
        success: true,
        message: "e-KYC ஆவணங்கள் வெற்றிகரமாக சமர்ப்பிக்கப்பட்டன. சரிபார்ப்பு நிலுவையில் உள்ளது.",
        kycId,
        status: "pending",
        submittedAt: new Date().toISOString(),
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("KYC submission error:", error)
    return NextResponse.json(
      { success: false, message: "e-KYC சமர்ப்பிப்பில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்." },
      { status: 500 },
    )
  }
}
