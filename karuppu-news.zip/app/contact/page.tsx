"use client"

import type React from "react"

import { useState } from "react"
import { Mail, Phone, MapPin, Clock, Facebook, Twitter, Instagram, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/components/ui/use-toast"

export default function ContactPage() {
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formStatus, setFormStatus] = useState<{
    type: "success" | "error" | null
    message: string
  }>({
    type: null,
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setFormStatus({ type: null, message: "" })

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (response.ok) {
        setFormStatus({
          type: "success",
          message: data.message,
        })
        setFormData({
          name: "",
          email: "",
          subject: "",
          message: "",
        })
        toast({
          title: "வெற்றி!",
          description: data.message,
        })
      } else {
        setFormStatus({
          type: "error",
          message: data.message || "ஏதோ தவறு நடந்தது. மீண்டும் முயற்சிக்கவும்.",
        })
        toast({
          variant: "destructive",
          title: "பிழை!",
          description: data.message || "ஏதோ தவறு நடந்தது. மீண்டும் முயற்சிக்கவும்.",
        })
      }
    } catch (error) {
      console.error("Contact form submission error:", error)
      setFormStatus({
        type: "error",
        message: "சேவையகத்துடன் தொடர்பு கொள்ள முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
      })
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "சேவையகத்துடன் தொடர்பு கொள்ள முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold mb-4">தொடர்பு கொள்ள</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          கருப்பு எழுத்துக் கழகத்தை தொடர்பு கொள்ள கீழே உள்ள விவரங்களைப் பயன்படுத்தவும் அல்லது படிவத்தை நிரப்பவும்.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold mb-6">எங்களை தொடர்பு கொள்ளுங்கள்</h2>
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">மின்னஞ்சல்</h3>
                <p className="text-muted-foreground">hello@karuppu.in</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">தொலைபேசி</h3>
                <p className="text-muted-foreground">+91 7826994499</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <MapPin className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">முகவரி</h3>
                <p className="text-muted-foreground">
                  14, எழிலன்மன் காலனி,
                  <br />
                  சென்னை, தமிழ்நாடு, இந்தியா
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">அலுவலக நேரம்</h3>
                <p className="text-muted-foreground">திங்கள் - சனி: காலை 9 மணி முதல் மாலை 6 மணி வரை</p>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="font-medium mb-4">சமூக ஊடகங்களில் எங்களை பின்தொடருங்கள்</h3>
            <div className="flex gap-4">
              <a
                href="https://www.facebook.com/karuppuezhutthu"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#1877F2] text-white p-3 rounded-full hover:opacity-90"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://x.com/karuppuTv"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-black text-white p-3 rounded-full hover:opacity-90"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="https://www.instagram.com/karuppunews"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCAF45] text-white p-3 rounded-full hover:opacity-90"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div>
          <Card>
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-6">எங்களுக்கு எழுதுங்கள்</h2>
              {formStatus.type && (
                <Alert
                  className={`mb-4 ${
                    formStatus.type === "success"
                      ? "bg-green-50 text-green-800 border-green-200"
                      : "bg-red-50 text-red-800 border-red-200"
                  }`}
                >
                  <AlertDescription>{formStatus.message}</AlertDescription>
                </Alert>
              )}
              <form className="space-y-4" onSubmit={handleSubmit}>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      பெயர் <span className="text-red-500">*</span>
                    </label>
                    <Input id="name" placeholder="உங்கள் பெயர்" value={formData.name} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      மின்னஞ்சல் <span className="text-red-500">*</span>
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium">
                    தலைப்பு <span className="text-red-500">*</span>
                  </label>
                  <Input
                    id="subject"
                    placeholder="உங்கள் செய்தியின் தலைப்பு"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    செய்தி <span className="text-red-500">*</span>
                  </label>
                  <Textarea
                    id="message"
                    placeholder="உங்கள் செய்தியை இங்கே எழுதுங்கள்"
                    rows={5}
                    value={formData.message}
                    onChange={handleChange}
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> அனுப்புகிறது...
                    </>
                  ) : (
                    "அனுப்புக"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="mt-12">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d248849.84916296526!2d80.06892754326367!3d13.047525828450945!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5265ea4f7d3361%3A0x6e61a70b6863d433!2sChennai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1715358000000!5m2!1sen!2sin"
          width="100%"
          height="450"
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
    </div>
  )
}
