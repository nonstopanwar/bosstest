import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarDays, Clock, Eye, ArrowRight } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample news data
const allNews = [
  {
    id: 1,
    title: "பல சிறுமிகளின் | பெண்களின் வாழ்வை இன்ஸ்டாகிராம் மூலம் சீரழித்த காமக் கொடூரனை கைது செய்யாமல் விட்ட காவல்துறை",
    excerpt:
      "உயிரிழந்த குழந்தையின் உறவுகளை மிரட்டிய கேணிக்கரை காவல் ஆய்வாளர் மீது நடவடிக்கை பாயுமா? அவனது instagram சாட் ஆயவுசெய்தபொது பல பெண்களின் | குழந்தைகளின் வாழக்கையை சீரழித்தது மட்டுமல்லாது பல அரசியல் பிரமுகர்களுக்கு அவனுடன் தொடர்புள்ளதாக தெரியவருகிறது.",
    content:
      "உயிரிழந்த குழந்தையின் உறவுகளை மிரட்டிய கேணிக்கரை காவல் ஆய்வாளர் மீது நடவடிக்கை பாயுமா? அவனது instagram சாட் ஆயவுசெய்தபொது பல பெண்களின் | குழந்தைகளின் வாழக்கையை சீரழித்தது மட்டுமல்லாது பல அரசியல் பிரமுகர்களுக்கு அவனுடன் தொடர்புள்ளதாக தெரியவருகிறது. இது பொள்ளாச்சி சம்பவத்தை விட பல மடங்கு பெரியது என சமூக ஆர்வலர்கள் கூறி வருகின்றனர்.",
    date: "2025-05-10",
    time: "10:30 AM",
    category: "குற்றம்",
    image: "/crime-news-investigation.png",
    tags: ["காவல்துறை", "குற்றம்", "இராமநாதபுரம்", "மனித உரிமைகள்"],
    views: 1245,
    featured: true,
  },
  {
    id: 2,
    title: "ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம்",
    excerpt: "கருப்பு எழுத்துக் கழகம் சார்பில் ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம் நடைபெற்றது.",
    content:
      "கருப்பு எழுத்துக் கழகம் சார்பில் ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம் நடைபெற்றது. இந்த கருத்தரங்கில் பல்வேறு துறைகளைச் சேர்ந்த அதிகாரிகள் மற்றும் சமூக ஆர்வலர்கள் கலந்து கொண்டனர்.",
    date: "2025-05-08",
    time: "10:30 AM",
    category: "நிகழ்வுகள்",
    image: "/anti-corruption-event.png",
    tags: ["ஊழல்", "விழிப்புணர்வு", "கருத்தரங்கம்"],
    views: 856,
    featured: true,
  },
  {
    id: 3,
    title: "ஊழல் புகார் எண் அறிமுகம்: 24 மணி நேரமும் செயல்படும்",
    excerpt: "பொதுமக்கள் ஊழல் குறித்து புகார் அளிக்க 24 மணி நேரமும் செயல்படும் புகார் எண் அறிமுகம் செய்யப்பட்டுள்ளது.",
    content:
      "பொதுமக்கள் ஊழல் குறித்து புகார் அளிக்க 24 மணி நேரமும் செயல்படும் புகார் எண் அறிமுகம் செய்யப்பட்டுள்ளது. இந்த புகார் எண் மூலம் பொதுமக்கள் ஊழல் குறித்த தகவல்களை அளிக்கலாம்.",
    date: "2025-05-05",
    time: "02:15 PM",
    category: "அறிவிப்புகள்",
    image: "/corruption-helpline.png",
    tags: ["ஊழல்", "புகார்", "அறிவிப்பு"],
    views: 723,
    featured: false,
  },
  {
    id: 4,
    title: "ஊழல் ஒழிப்பு போராட்டம்: மாணவர்கள் பங்கேற்பு",
    excerpt: "ஊழல் ஒழிப்பு குறித்த விழிப்புணர்வை ஏற்படுத்தும் வகையில் மாணவர்கள் போராட்டத்தில் பங்கேற்றனர்.",
    content:
      "ஊழல் ஒழிப்பு குறித்த விழிப்புணர்வை ஏற்படுத்தும் வகையில் மாணவர்கள் போராட்டத்தில் பங்கேற்றனர். இந்த போராட்டத்தில் பல்கலைக்கழக மாணவர்கள் மற்றும் பள்ளி மாணவர்கள் கலந்து கொண்டனர்.",
    date: "2025-05-03",
    time: "11:45 AM",
    category: "செய்திகள்",
    image: "/student-anti-corruption-protest.png",
    tags: ["ஊழல்", "போராட்டம்", "மாணவர்கள்"],
    views: 645,
    featured: false,
  },
  {
    id: 5,
    title: "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல்",
    excerpt: "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல் நிகழ்ச்சி நடைபெற்றது.",
    content:
      "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல் நிகழ்ச்சி நடைபெற்றது. இந்த நிகழ்ச்சியில் சட்ட வல்லுநர்கள் மற்றும் அரசு அதிகாரிகள் கலந்து கொண்டனர்.",
    date: "2025-05-01",
    time: "03:30 PM",
    category: "சட்டம்",
    image: "/legal-discussion.png",
    tags: ["ஊழல்", "சட்டம்", "கலந்துரையாடல்"],
    views: 532,
    featured: false,
  },
  {
    id: 6,
    title: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி",
    excerpt: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி நடைபெற்றது.",
    content: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி நடைபெற்றது. இந்த பேரணியில் பல்வேறு சமூக அமைப்புகள் மற்றும் பொதுமக்கள் கலந்து கொண்டனர்.",
    date: "2025-04-28",
    time: "10:00 AM",
    category: "நிகழ்வுகள்",
    image: "/anti-corruption-rally.png",
    tags: ["ஊழல்", "விழிப்புணர்வு", "பேரணி"],
    views: 478,
    featured: false,
  },
]

// Categories
const categories = [
  { value: "all", label: "அனைத்தும்" },
  { value: "குற்றம்", label: "குற்றம்" },
  { value: "நிகழ்வுகள்", label: "நிகழ்வுகள்" },
  { value: "அறிவிப்புகள்", label: "அறிவிப்புகள்" },
  { value: "செய்திகள்", label: "செய்திகள்" },
  { value: "சட்டம்", label: "சட்டம்" },
]

export default function NewsPage() {
  return (
    <div className="container mx-auto py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold mb-4">செய்திகள்</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          கருப்பு எழுத்துக் கழகத்தின் அனைத்து செய்திகளையும் இங்கே காணலாம்
        </p>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="flex flex-wrap justify-center mb-6">
          {categories.map((category) => (
            <TabsTrigger key={category.value} value={category.value}>
              {category.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {categories.map((category) => (
          <TabsContent key={category.value} value={category.value}>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allNews
                .filter((news) => category.value === "all" || news.category === category.value)
                .map((news) => (
                  <Card key={news.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative h-48">
                      <Image src={news.image || "/placeholder.svg"} alt={news.title} fill className="object-cover" />
                      <Badge className="absolute top-2 right-2 bg-primary">{news.category}</Badge>
                    </div>
                    <CardHeader className="p-4">
                      <CardTitle className="text-xl line-clamp-2">{news.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <CardDescription className="line-clamp-3 mb-4">{news.excerpt}</CardDescription>
                      <div className="flex items-center text-sm text-muted-foreground gap-4">
                        <div className="flex items-center">
                          <CalendarDays className="mr-1 h-4 w-4" />
                          {news.date}
                        </div>
                        <div className="flex items-center">
                          <Clock className="mr-1 h-4 w-4" />
                          {news.time}
                        </div>
                        <div className="flex items-center">
                          <Eye className="mr-1 h-4 w-4" />
                          {news.views}
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="p-4 pt-0">
                      <Link href={`/news/${news.id}`}>
                        <Button variant="link" className="p-0 text-primary">
                          மேலும் படிக்க <ArrowRight className="ml-1 h-4 w-4" />
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
