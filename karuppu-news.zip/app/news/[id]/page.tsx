import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { CalendarDays, Clock, Eye, Share2, Facebook, Twitter, ArrowLeft } from "lucide-react"

// Sample news data
const allNews = [
  {
    id: 1,
    title: "பல சிறுமிகளின் | பெண்களின் வாழ்வை இன்ஸ்டாகிராம் மூலம் சீரழித்த காமக் கொடூரனை கைது செய்யாமல் விட்ட காவல்துறை",
    excerpt:
      "உயிரிழந்த குழந்தையின் உறவுகளை மிரட்டிய கேணிக்கரை காவல் ஆய்வாளர் மீது நடவடிக்கை பாயுமா? அவனது instagram சாட் ஆயவுசெய்தபொது பல பெண்களின் | குழந்தைகளின் வாழக்கையை சீரழித்தது மட்டுமல்லாது பல அரசியல் பிரமுகர்களுக்கு அவனுடன் தொடர்புள்ளதாக தெரியவருகிறது.",
    content: `<p>உயிரிழந்த குழந்தையின் உறவுகளை மிரட்டிய கேணிக்கரை காவல் ஆய்வாளர் மீது நடவடிக்கை பாயுமா? அவனது instagram சாட் ஆயவுசெய்தபொது பல பெண்களின் | குழந்தைகளின் வாழக்கையை சீரழித்தது மட்டுமல்லாது பல அரசியல் பிரமுகர்களுக்கு அவனுடன் தொடர்புள்ளதாக தெரியவருகிறது.</p>
    
    <div class="my-6">
      <figure class="relative">
        <img src="/suspect-image.png" alt="சந்தேக நபர்" class="w-full rounded-lg" />
        <figcaption class="text-sm text-muted-foreground mt-2 text-center">சந்தேக நபரின் புகைப்படம் - சமூக ஊடகங்களில் இருந்து பெறப்பட்டது</figcaption>
      </figure>
    </div>
    
    <p>இது பொள்ளாச்சி சம்பவத்தை விட பல மடங்கு பெரியது என சமூக ஆர்வலர்கள் கூறி வருகின்றனர்.</p>
    
    <div class="bg-amber-50 border-l-4 border-amber-500 p-4 my-6">
      <div class="flex items-center gap-2 text-amber-700 font-medium mb-2">
        <AlertTriangle className="h-5 w-5" />
        <span>எச்சரிக்கை</span>
      </div>
      <p class="text-amber-700">இந்த செய்தியில் உள்ள சில விவரங்கள் உணர்ச்சிகரமானவை. பாதிக்கப்பட்டவர்களின் அடையாளம் பாதுகாக்கப்பட்டுள்ளது.</p>
    </div>
    
    <p>இந்த விவகாரத்தில் இராமநாதபுரம் மாவட்ட காவல்துறை, தமிழ்நாடு காவல்துறை தெற்கு மண்டலம், தேசிய மனித உரிமைகள் ஆணையம், தமிழ்நாடு காவல்துறை, முதலமைச்சர் மு.க. ஸ்டாலின், தேசிய தாழ்த்தப்பட்டோர் ஆணையம், இராமநாதபுரம் மாவட்ட ஆட்சியர் ஆகியோர் உடனடி நடவடிக்கை எடுக்க வேண்டும் என்று கோரிக்கை வைக்கப்பட்டுள்ளது.</p>
    
    <div class="my-6">
      <h3 class="text-lg font-medium mb-3">சமூக ஆர்வலர்களின் கருத்து</h3>
      <div class="aspect-w-16 aspect-h-9 mb-4">
        <div class="w-full h-full">
          <VideoPlayer videoId="news-report-video" />
        </div>
      </div>
      <p class="text-sm text-muted-foreground mt-2">சமூக ஆர்வலர்கள் இந்த விவகாரம் குறித்து கருத்து தெரிவிக்கின்றனர்</p>
    </div>
    
    <p>இந்த சம்பவம் குறித்து பல சமூக ஆர்வலர்கள் கண்டனம் தெரிவித்துள்ளனர். குற்றவாளிகளை உடனடியாக கைது செய்து, கடுமையான நடவடிக்கை எடுக்க வேண்டும் என்று வலியுறுத்தியுள்ளனர்.</p>
    
    <p>இந்த விவகாரத்தில் சம்பந்தப்பட்ட அனைவரும் கடுமையாக தண்டிக்கப்பட வேண்டும் என்று பொதுமக்கள் கோரிக்கை வைத்துள்ளனர்.</p>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 my-6">
      <figure class="relative">
        <img src="/protest-image-1.png" alt="போராட்டம்" class="w-full h-48 object-cover rounded-lg" />
        <figcaption class="text-sm text-muted-foreground mt-2">பொதுமக்கள் நீதி கேட்டு போராட்டம்</figcaption>
      </figure>
      <figure class="relative">
        <img src="/protest-image-2.png" alt="போராட்டம்" class="w-full h-48 object-cover rounded-lg" />
        <figcaption class="text-sm text-muted-foreground mt-2">மாணவர்கள் கண்டன ஆர்ப்பாட்டம்</figcaption>
      </figure>
    </div>`,
    date: "2025-05-10",
    time: "10:30 AM",
    category: "குற்றம்",
    image: "/crime-news-investigation.png",
    tags: ["காவல்துறை", "குற்றம்", "இராமநாதபுரம்", "மனித உரிமைகள்"],
    views: 1245,
    featured: true,
    author: {
      name: "கருப்பு செய்தியாளர்",
      image: "/journalist-interview.png",
      role: "முதன்மை செய்தியாளர்",
    },
    relatedNews: [2, 3, 4],
    gallery: [
      {
        src: "/suspect-image.png",
        alt: "சந்தேக நபர்",
        caption: "சந்தேக நபரின் புகைப்படம் - சமூக ஊடகங்களில் இருந்து பெறப்பட்டது",
      },
      {
        src: "/protest-image-1.png",
        alt: "போராட்டம்",
        caption: "பொதுமக்கள் நீதி கேட்டு போராட்டம்",
      },
      {
        src: "/protest-image-2.png",
        alt: "போராட்டம்",
        caption: "மாணவர்கள் கண்டன ஆர்ப்பாட்டம்",
      },
    ],
  },
  {
    id: 2,
    title: "ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம்",
    excerpt: "கருப்பு எழுத்துக் கழகம் சார்பில் ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம் நடைபெற்றது.",
    content:
      "கருப்பு எழுத்துக் கழகம் சார்பில் ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம் நடைபெற்றது. இந்த கருத்தரங்கில் பல்வேறு துறைகளைச் சேர்ந்த அதிகாரிகள் மற்றும் சமூக ஆர்வலர்கள் கலந்து கொண்டனர்.",
    date: "2025-05-08",
    time: "10:30 AM",
    category: "நிகழ்வுகள்",
    image: "/anti-corruption-event.png",
    tags: ["ஊழல்", "விழிப்புணர்வு", "கருத்தரங்கம்"],
    views: 856,
    featured: true,
    author: {
      name: "கருப்பு செய்தியாளர்",
      image: "/journalist-interview.png",
      role: "முதன்மை செய்தியாளர்",
    },
    relatedNews: [3, 4, 5],
  },
  {
    id: 3,
    title: "ஊழல் புகார் எண் அறிமுகம்: 24 மணி நேரமும் செயல்படும்",
    excerpt: "பொதுமக்கள் ஊழல் குறித்து புகார் அளிக்க 24 மணி நேரமும் செயல்படும் புகார் எண் அறிமுகம் செய்யப்பட்டுள்ளது.",
    content:
      "பொதுமக்கள் ஊழல் குறித்து புகார் அளிக்க 24 மணி நேரமும் செயல்படும் புகார் எண் அறிமுகம் செய்யப்பட்டுள்ளது. இந்த புகார் எண் மூலம் பொதுமக்கள் ஊழல் குறித்த தகவல்களை அளிக்கலாம்.",
    date: "2025-05-05",
    time: "02:15 PM",
    category: "அறிவிப்புகள்",
    image: "/corruption-helpline.png",
    tags: ["ஊழல்", "புகார்", "அறிவிப்பு"],
    views: 723,
    featured: false,
    author: {
      name: "கருப்பு செய்தியாளர்",
      image: "/journalist-interview.png",
      role: "முதன்மை செய்தியாளர்",
    },
    relatedNews: [2, 4, 5],
  },
  {
    id: 4,
    title: "ஊழல் ஒழிப்பு போராட்டம்: மாணவர்கள் பங்கேற்பு",
    excerpt: "ஊழல் ஒழிப்பு குறித்த விழிப்புணர்வை ஏற்படுத்தும் வகையில் மாணவர்கள் போராட்டத்தில் பங்கேற்றனர்.",
    content:
      "ஊழல் ஒழிப்பு குறித்த விழிப்புணர்வை ஏற்படுத்தும் வகையில் மாணவர்கள் போராட்டத்தில் பங்கேற்றனர். இந்த போராட்டத்தில் பல்கலைக்கழக மாணவர்கள் மற்றும் பள்ளி மாணவர்கள் கலந்து கொண்டனர்.",
    date: "2025-05-03",
    time: "11:45 AM",
    category: "செய்திகள்",
    image: "/student-anti-corruption-protest.png",
    tags: ["ஊழல்", "போராட்டம்", "மாணவர்கள்"],
    views: 645,
    featured: false,
    author: {
      name: "கருப்பு செய்தியாளர்",
      image: "/journalist-interview.png",
      role: "முதன்மை செய்தியாளர்",
    },
    relatedNews: [2, 3, 5],
  },
  {
    id: 5,
    title: "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல்",
    excerpt: "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல் நிகழ்ச்சி நடைபெற்றது.",
    content:
      "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல் நிகழ்ச்சி நடைபெற்றது. இந்த நிகழ்ச்சியில் சட்ட வல்லுநர்கள் மற்றும் அரசு அதிகாரிகள் கலந்து கொண்டனர்.",
    date: "2025-05-01",
    time: "03:30 PM",
    category: "சட்டம்",
    image: "/legal-discussion.png",
    tags: ["ஊழல்", "சட்டம்", "கலந்துரையாடல்"],
    views: 532,
    featured: false,
    author: {
      name: "கருப்பு செய்தியாளர்",
      image: "/journalist-interview.png",
      role: "முதன்மை செய்தியாளர்",
    },
    relatedNews: [2, 3, 4],
  },
  {
    id: 6,
    title: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி",
    excerpt: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி நடைபெற்றது.",
    content: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி நடைபெற்றது. இந்த பேரணியில் பல்வேறு சமூக அமைப்புகள் மற்றும் பொதுமக்கள் கலந்து கொண்டனர்.",
    date: "2025-04-28",
    time: "10:00 AM",
    category: "நிகழ்வுகள்",
    image: "/anti-corruption-rally.png",
    tags: ["ஊழல்", "விழிப்புணர்வு", "பேரணி"],
    views: 478,
    featured: false,
    author: {
      name: "கருப்பு செய்தியாளர்",
      image: "/journalist-interview.png",
      role: "முதன்மை செய்தியாளர்",
    },
    relatedNews: [2, 3, 4],
  },
]

export default function NewsDetailPage({ params }: { params: { id: string } }) {
  const newsId = Number.parseInt(params.id)
  const news = allNews.find((item) => item.id === newsId)

  if (!news) {
    notFound()
  }

  const relatedNews = news.relatedNews ? allNews.filter((item) => news.relatedNews?.includes(item.id)) : []

  return (
    <div className="container mx-auto py-12">
      <div className="mb-6">
        <Link href="/news" className="flex items-center text-primary hover:underline">
          <ArrowLeft className="mr-2 h-4 w-4" />
          அனைத்து செய்திகளுக்கும் திரும்பிச் செல்ல
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="mb-6">
            <Badge className="mb-4">{news.category}</Badge>
            <h1 className="text-3xl font-bold mb-4">{news.title}</h1>
            <div className="flex items-center text-sm text-muted-foreground gap-4 mb-4">
              <div className="flex items-center">
                <CalendarDays className="mr-1 h-4 w-4" />
                {news.date}
              </div>
              <div className="flex items-center">
                <Clock className="mr-1 h-4 w-4" />
                {news.time}
              </div>
              <div className="flex items-center">
                <Eye className="mr-1 h-4 w-4" />
                {news.views} பார்வைகள்
              </div>
            </div>
          </div>

          <div className="relative h-[400px] mb-6">
            <Image src={news.image || "/placeholder.svg"} alt={news.title} fill className="object-cover rounded-lg" />
          </div>

          <div className="prose prose-lg max-w-none mb-8" dangerouslySetInnerHTML={{ __html: news.content }} />

          {news.gallery && news.gallery.length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-bold mb-4">புகைப்பட தொகுப்பு</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {news.gallery.map((image, index) => (
                  <figure key={index} className="relative">
                    <Image
                      src={image.src || "/placeholder.svg"}
                      alt={image.alt}
                      width={400}
                      height={300}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    <figcaption className="text-sm text-muted-foreground mt-2">{image.caption}</figcaption>
                  </figure>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-wrap gap-2 mb-8">
            {news.tags.map((tag) => (
              <Badge key={tag} variant="outline">
                #{tag}
              </Badge>
            ))}
          </div>

          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-4">
              <div className="relative w-12 h-12 rounded-full overflow-hidden">
                <Image
                  src={news.author.image || "/placeholder.svg"}
                  alt={news.author.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <p className="font-medium">{news.author.name}</p>
                <p className="text-sm text-muted-foreground">{news.author.role}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="icon" variant="outline">
                <Share2 className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                variant="outline"
                className="bg-[#1877F2] text-white border-[#1877F2] hover:bg-[#1877F2]/90 hover:text-white"
              >
                <Facebook className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                variant="outline"
                className="bg-black text-white border-black hover:bg-black/90 hover:text-white"
              >
                <Twitter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div>
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">தொடர்புடைய செய்திகள்</h2>
              <div className="space-y-4">
                {relatedNews.map((item) => (
                  <div key={item.id} className="flex gap-4">
                    <div className="relative w-20 h-20 flex-shrink-0">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.title}
                        fill
                        className="object-cover rounded"
                      />
                    </div>
                    <div>
                      <Link href={`/news/${item.id}`} className="font-medium hover:text-primary line-clamp-2">
                        {item.title}
                      </Link>
                      <div className="flex items-center text-xs text-muted-foreground mt-1">
                        <CalendarDays className="mr-1 h-3 w-3" />
                        {item.date}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">பிரபலமான குறிச்சொற்கள்</h2>
              <div className="flex flex-wrap gap-2">
                {["ஊழல்", "காவல்துறை", "குற்றம்", "விழிப்புணர்வு", "போராட்டம்", "மாணவர்கள்", "சட்டம்", "அரசியல்", "மனித உரிமைகள்"].map(
                  (tag) => (
                    <Badge key={tag} variant="outline" className="hover:bg-primary hover:text-white cursor-pointer">
                      #{tag}
                    </Badge>
                  ),
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
