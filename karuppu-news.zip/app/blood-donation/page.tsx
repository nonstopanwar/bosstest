"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { AlertCircle, Search, MapPin, Phone, Calendar, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/components/ui/use-toast"

// Blood groups
const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]

// Sample districts
const districts = [
  "சென்னை",
  "கோயம்புத்தூர்",
  "மதுரை",
  "திருச்சி",
  "சேலம்",
  "திருநெல்வேலி",
  "தூத்துக்குடி",
  "ஈரோடு",
  "வேலூர்",
  "தஞ்சாவூர்",
  "திண்டுக்கல்",
  "கன்னியாகுமரி",
]

// Sample blood donation requests
const donationRequests = [
  {
    id: 1,
    patientName: "ராஜேஷ்",
    bloodGroup: "O+",
    hospital: "அப்பல்லோ மருத்துவமனை",
    location: "சென்னை",
    contactName: "சுரேஷ்",
    contactPhone: "9876543210",
    unitsNeeded: 2,
    urgency: "high",
    date: "2025-05-15",
    description: "விபத்தில் காயமடைந்த நோயாளிக்கு அவசரமாக இரத்தம் தேவை.",
    status: "active",
  },
  {
    id: 2,
    patientName: "மாலதி",
    bloodGroup: "A+",
    hospital: "மீனாட்சி மருத்துவமனை",
    location: "மதுரை",
    contactName: "கார்த்திக்",
    contactPhone: "9876543211",
    unitsNeeded: 1,
    urgency: "medium",
    date: "2025-05-18",
    description: "அறுவை சிகிச்சைக்கு இரத்தம் தேவை.",
    status: "active",
  },
  {
    id: 3,
    patientName: "விஜய்",
    bloodGroup: "AB-",
    hospital: "ராஜீவ் காந்தி மருத்துவமனை",
    location: "கோயம்புத்தூர்",
    contactName: "அனிதா",
    contactPhone: "9876543212",
    unitsNeeded: 3,
    urgency: "high",
    date: "2025-05-16",
    description: "தலசீமியா நோயாளிக்கு அவசரமாக இரத்தம் தேவை.",
    status: "active",
  },
  {
    id: 4,
    patientName: "கவிதா",
    bloodGroup: "B+",
    hospital: "அரசு மருத்துவமனை",
    location: "திருச்சி",
    contactName: "பிரகாஷ்",
    contactPhone: "9876543213",
    unitsNeeded: 2,
    urgency: "low",
    date: "2025-05-20",
    description: "திட்டமிட்ட அறுவை சிகிச்சைக்கு இரத்தம் தேவை.",
    status: "active",
  },
]

// Sample blood donors
const bloodDonors = [
  {
    id: 1,
    name: "ராஜேந்திரன்",
    bloodGroup: "O+",
    district: "சென்னை",
    phone: "9876543210",
    lastDonated: "2025-02-15",
    timesdonated: 5,
  },
  {
    id: 2,
    name: "கவிதா",
    bloodGroup: "A+",
    district: "மதுரை",
    phone: "9876543211",
    lastDonated: "2025-01-10",
    timesdonated: 3,
  },
  {
    id: 3,
    name: "சுரேஷ்",
    bloodGroup: "AB-",
    district: "கோயம்புத்தூர்",
    phone: "9876543212",
    lastDonated: "2025-03-05",
    timesdonated: 7,
  },
  {
    id: 4,
    name: "அனிதா",
    bloodGroup: "B+",
    district: "திருச்சி",
    phone: "9876543213",
    lastDonated: "2025-04-20",
    timesdonated: 2,
  },
]

export default function BloodDonationPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("requests")
  const [searchTerm, setSearchTerm] = useState("")
  const [bloodGroupFilter, setBloodGroupFilter] = useState("all")
  const [locationFilter, setLocationFilter] = useState("all")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  // New request form state
  const [requestForm, setRequestForm] = useState({
    patientName: "",
    bloodGroup: "",
    hospital: "",
    location: "",
    contactName: "",
    contactPhone: "",
    unitsNeeded: "1",
    urgency: "medium",
    date: "",
    description: "",
    termsAccepted: false,
  })

  // Donor registration form state
  const [donorForm, setDonorForm] = useState({
    name: "",
    bloodGroup: "",
    district: "",
    phone: "",
    lastDonated: "",
    termsAccepted: false,
  })

  // Filter requests based on search and filters
  const filteredRequests = donationRequests.filter((request) => {
    const matchesSearch =
      request.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.hospital.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.location.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesBloodGroup = bloodGroupFilter === "all" || request.bloodGroup === bloodGroupFilter
    const matchesLocation = locationFilter === "all" || request.location === locationFilter

    return matchesSearch && matchesBloodGroup && matchesLocation
  })

  // Filter donors based on search and filters
  const filteredDonors = bloodDonors.filter((donor) => {
    const matchesSearch =
      donor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      donor.district.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesBloodGroup = bloodGroupFilter === "all" || donor.bloodGroup === bloodGroupFilter
    const matchesLocation = locationFilter === "all" || donor.district === locationFilter

    return matchesSearch && matchesBloodGroup && matchesLocation
  })

  const handleRequestFormChange = (field: string, value: string | boolean) => {
    setRequestForm((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleDonorFormChange = (field: string, value: string | boolean) => {
    setDonorForm((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (
      !requestForm.patientName ||
      !requestForm.bloodGroup ||
      !requestForm.hospital ||
      !requestForm.location ||
      !requestForm.contactName ||
      !requestForm.contactPhone ||
      !requestForm.date
    ) {
      setError("அனைத்து அவசியமான புலங்களையும் நிரப்பவும்")
      return
    }

    if (!requestForm.termsAccepted) {
      setError("விதிமுறைகள் மற்றும் நிபந்தனைகளை ஏற்க வேண்டும்")
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, this would be an API call to submit the request
      // For now, we'll simulate a successful submission
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "வெற்றி!",
        description: "இரத்த தான கோரிக்கை வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது.",
      })

      // Reset form
      setRequestForm({
        patientName: "",
        bloodGroup: "",
        hospital: "",
        location: "",
        contactName: "",
        contactPhone: "",
        unitsNeeded: "1",
        urgency: "medium",
        date: "",
        description: "",
        termsAccepted: false,
      })

      // Switch to requests tab
      setActiveTab("requests")
    } catch (error) {
      console.error("Request submission error:", error)
      setError("கோரிக்கை சமர்ப்பிப்பில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDonorSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!donorForm.name || !donorForm.bloodGroup || !donorForm.district || !donorForm.phone) {
      setError("அனைத்து அவசியமான புலங்களையும் நிரப்பவும்")
      return
    }

    if (!donorForm.termsAccepted) {
      setError("விதிமுறைகள் மற்றும் நிபந்தனைகளை ஏற்க வேண்டும்")
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, this would be an API call to register as a donor
      // For now, we'll simulate a successful registration
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "வெற்றி!",
        description: "இரத்த தானம் செய்ய பதிவு வெற்றிகரமாக முடிந்தது.",
      })

      // Reset form
      setDonorForm({
        name: "",
        bloodGroup: "",
        district: "",
        phone: "",
        lastDonated: "",
        termsAccepted: false,
      })

      // Switch to donors tab
      setActiveTab("donors")
    } catch (error) {
      console.error("Donor registration error:", error)
      setError("பதிவில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold mb-4">இரத்த தான மையம்</h1>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
          இரத்த தானம் செய்வது உயிர்களைக் காப்பாற்றும். ஒரு நபர் இரத்த தானம் செய்வதன் மூலம் மூன்று பேரின் உயிரைக் காப்பாற்ற முடியும்.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="requests">இரத்த தேவை</TabsTrigger>
          <TabsTrigger value="donors">இரத்த தானம் செய்பவர்கள்</TabsTrigger>
          <TabsTrigger value="new-request">புதிய கோரிக்கை</TabsTrigger>
          <TabsTrigger value="register">தானம் செய்ய பதிவு</TabsTrigger>
        </TabsList>

        {/* Blood Requests Tab */}
        <TabsContent value="requests">
          <Card>
            <CardHeader>
              <CardTitle>இரத்த தேவை கோரிக்கைகள்</CardTitle>
              <CardDescription>தற்போதைய இரத்த தேவை கோரிக்கைகளைக் காண்க</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="relative">
                  <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="தேட..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                <div>
                  <Select value={bloodGroupFilter} onValueChange={setBloodGroupFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="இரத்த வகை" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">அனைத்து இரத்த வகைகளும்</SelectItem>
                      {bloodGroups.map((group) => (
                        <SelectItem key={group} value={group}>
                          {group}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Select value={locationFilter} onValueChange={setLocationFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="இடம்" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">அனைத்து இடங்களும்</SelectItem>
                      {districts.map((district) => (
                        <SelectItem key={district} value={district}>
                          {district}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredRequests.length > 0 ? (
                  filteredRequests.map((request) => (
                    <Card key={request.id} className="overflow-hidden">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">{request.patientName}</CardTitle>
                            <CardDescription>{request.hospital}</CardDescription>
                          </div>
                          <Badge
                            className={
                              request.urgency === "high"
                                ? "bg-red-500"
                                : request.urgency === "medium"
                                  ? "bg-yellow-500"
                                  : "bg-green-500"
                            }
                          >
                            {request.urgency === "high"
                              ? "அவசரம்"
                              : request.urgency === "medium"
                                ? "நடுத்தரம்"
                                : "குறைந்த அவசரம்"}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-lg font-bold">
                              {request.bloodGroup}
                            </Badge>
                            <span>{request.unitsNeeded} யூனிட்(கள்) தேவை</span>
                          </div>

                          <div className="flex items-center text-sm text-muted-foreground">
                            <MapPin className="h-4 w-4 mr-1" />
                            {request.location}
                          </div>

                          <div className="flex items-center text-sm text-muted-foreground">
                            <Calendar className="h-4 w-4 mr-1" />
                            {request.date}
                          </div>

                          <div className="flex items-center text-sm">
                            <Phone className="h-4 w-4 mr-1" />
                            <span>
                              {request.contactName}: {request.contactPhone}
                            </span>
                          </div>

                          {request.description && <p className="text-sm mt-2">{request.description}</p>}
                        </div>
                      </CardContent>
                      <div className="p-4 pt-0">
                        <Button className="w-full bg-primary hover:bg-primary/90">தானம் செய்ய அழைக்க</Button>
                      </div>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-full text-center py-8">
                    <p className="text-muted-foreground">கோரிக்கைகள் எதுவும் கிடைக்கவில்லை</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Blood Donors Tab */}
        <TabsContent value="donors">
          <Card>
            <CardHeader>
              <CardTitle>இரத்த தானம் செய்பவர்கள்</CardTitle>
              <CardDescription>பதிவு செய்யப்பட்ட இரத்த தானம் செய்பவர்களைக் காண்க</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="relative">
                  <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="தேட..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                <div>
                  <Select value={bloodGroupFilter} onValueChange={setBloodGroupFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="இரத்த வகை" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">அனைத்து இரத்த வகைகளும்</SelectItem>
                      {bloodGroups.map((group) => (
                        <SelectItem key={group} value={group}>
                          {group}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Select value={locationFilter} onValueChange={setLocationFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="இடம்" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">அனைத்து இடங்களும்</SelectItem>
                      {districts.map((district) => (
                        <SelectItem key={district} value={district}>
                          {district}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDonors.length > 0 ? (
                  filteredDonors.map((donor) => (
                    <Card key={donor.id}>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">{donor.name}</CardTitle>
                        <CardDescription>{donor.district}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-lg font-bold">
                              {donor.bloodGroup}
                            </Badge>
                            <span>{donor.timesdonated} முறை தானம் செய்துள்ளார்</span>
                          </div>

                          <div className="flex items-center text-sm text-muted-foreground">
                            <Calendar className="h-4 w-4 mr-1" />
                            கடைசியாக தானம் செய்தது: {donor.lastDonated}
                          </div>

                          <div className="flex items-center text-sm">
                            <Phone className="h-4 w-4 mr-1" />
                            <span>{donor.phone}</span>
                          </div>
                        </div>
                      </CardContent>
                      <div className="p-4 pt-0">
                        <Button className="w-full bg-primary hover:bg-primary/90">தொடர்பு கொள்ள</Button>
                      </div>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-full text-center py-8">
                    <p className="text-muted-foreground">தானம் செய்பவர்கள் எதுவும் கிடைக்கவில்லை</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* New Request Tab */}
        <TabsContent value="new-request">
          <Card>
            <CardHeader>
              <CardTitle>புதிய இரத்த தேவை கோரிக்கை</CardTitle>
              <CardDescription>இரத்த தேவை கோரிக்கையை சமர்ப்பிக்கவும்</CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleRequestSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="patientName">
                      நோயாளியின் பெயர் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="patientName"
                      value={requestForm.patientName}
                      onChange={(e) => handleRequestFormChange("patientName", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bloodGroup">
                      இரத்த வகை <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={requestForm.bloodGroup}
                      onValueChange={(value) => handleRequestFormChange("bloodGroup", value)}
                    >
                      <SelectTrigger id="bloodGroup">
                        <SelectValue placeholder="இரத்த வகையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {bloodGroups.map((group) => (
                          <SelectItem key={group} value={group}>
                            {group}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="hospital">
                      மருத்துவமனை <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="hospital"
                      value={requestForm.hospital}
                      onChange={(e) => handleRequestFormChange("hospital", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">
                      இடம் <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={requestForm.location}
                      onValueChange={(value) => handleRequestFormChange("location", value)}
                    >
                      <SelectTrigger id="location">
                        <SelectValue placeholder="இடத்தைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {districts.map((district) => (
                          <SelectItem key={district} value={district}>
                            {district}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contactName">
                      தொடர்பு பெயர் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="contactName"
                      value={requestForm.contactName}
                      onChange={(e) => handleRequestFormChange("contactName", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contactPhone">
                      தொடர்பு எண் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="contactPhone"
                      value={requestForm.contactPhone}
                      onChange={(e) => handleRequestFormChange("contactPhone", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="unitsNeeded">
                      தேவையான யூனிட்கள் <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={requestForm.unitsNeeded}
                      onValueChange={(value) => handleRequestFormChange("unitsNeeded", value)}
                    >
                      <SelectTrigger id="unitsNeeded">
                        <SelectValue placeholder="யூனிட்களைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5].map((unit) => (
                          <SelectItem key={unit} value={unit.toString()}>
                            {unit}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="urgency">
                      அவசர நிலை <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={requestForm.urgency}
                      onValueChange={(value) => handleRequestFormChange("urgency", value)}
                    >
                      <SelectTrigger id="urgency">
                        <SelectValue placeholder="அவசர நிலையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">அவசரம்</SelectItem>
                        <SelectItem value="medium">நடுத்தரம்</SelectItem>
                        <SelectItem value="low">குறைந்த அவசரம்</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">
                      தேதி <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="date"
                      type="date"
                      value={requestForm.date}
                      onChange={(e) => handleRequestFormChange("date", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="description">விளக்கம்</Label>
                    <Textarea
                      id="description"
                      placeholder="கூடுதல் விவரங்களை உள்ளிடவும்"
                      value={requestForm.description}
                      onChange={(e) => handleRequestFormChange("description", e.target.value)}
                      rows={3}
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2 mt-6">
                  <Checkbox
                    id="terms"
                    checked={requestForm.termsAccepted}
                    onCheckedChange={(checked) => handleRequestFormChange("termsAccepted", !!checked)}
                    required
                  />
                  <Label
                    htmlFor="terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    <span>
                      நான்{" "}
                      <a href="/terms" className="text-primary hover:underline">
                        விதிமுறைகள் மற்றும் நிபந்தனைகளை
                      </a>{" "}
                      ஏற்கிறேன்
                    </span>
                  </Label>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        சமர்ப்பிக்கிறது...
                      </>
                    ) : (
                      "கோரிக்கையை சமர்ப்பிக்க"
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Register as Donor Tab */}
        <TabsContent value="register">
          <Card>
            <CardHeader>
              <CardTitle>இரத்த தானம் செய்ய பதிவு</CardTitle>
              <CardDescription>இரத்த தானம் செய்ய தன்னார்வலராக பதிவு செய்யவும்</CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleDonorSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">
                      பெயர் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="name"
                      value={donorForm.name}
                      onChange={(e) => handleDonorFormChange("name", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="donor-bloodGroup">
                      இரத்த வகை <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={donorForm.bloodGroup}
                      onValueChange={(value) => handleDonorFormChange("bloodGroup", value)}
                    >
                      <SelectTrigger id="donor-bloodGroup">
                        <SelectValue placeholder="இரத்த வகையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {bloodGroups.map((group) => (
                          <SelectItem key={group} value={group}>
                            {group}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="district">
                      மாவட்டம் <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={donorForm.district}
                      onValueChange={(value) => handleDonorFormChange("district", value)}
                    >
                      <SelectTrigger id="district">
                        <SelectValue placeholder="மாவட்டத்தைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {districts.map((district) => (
                          <SelectItem key={district} value={district}>
                            {district}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">
                      தொலைபேசி எண் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="phone"
                      value={donorForm.phone}
                      onChange={(e) => handleDonorFormChange("phone", e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="lastDonated">கடைசியாக தானம் செய்த தேதி</Label>
                    <Input
                      id="lastDonated"
                      type="date"
                      value={donorForm.lastDonated}
                      onChange={(e) => handleDonorFormChange("lastDonated", e.target.value)}
                    />
                  </div>
                </div>

                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <h3 className="font-medium mb-2">இரத்த தானம் செய்வதற்கான தகுதிகள்:</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>வயது 18-65 இடையே இருக்க வேண்டும்</li>
                    <li>உடல் எடை 45 கிலோவுக்கு மேல் இருக்க வேண்டும்</li>
                    <li>ஹீமோகுளோபின் அளவு 12.5 g/dL க்கு மேல் இருக்க வேண்டும்</li>
                    <li>கடந்த 3 மாதங்களில் இரத்த தானம் செய்திருக்கக் கூடாது</li>
                    <li>நீரிழிவு, உயர் இரத்த அழுத்தம் போன்ற நோய்கள் இல்லாமல் இருக்க வேண்டும்</li>
                  </ul>
                </div>

                <div className="flex items-center space-x-2 mt-6">
                  <Checkbox
                    id="donor-terms"
                    checked={donorForm.termsAccepted}
                    onCheckedChange={(checked) => handleDonorFormChange("termsAccepted", !!checked)}
                    required
                  />
                  <Label
                    htmlFor="donor-terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    <span>
                      நான்{" "}
                      <a href="/terms" className="text-primary hover:underline">
                        விதிமுறைகள் மற்றும் நிபந்தனைகளை
                      </a>{" "}
                      ஏற்கிறேன் மற்றும் மேலே உள்ள தகுதிகளை பூர்த்தி செய்கிறேன்
                    </span>
                  </Label>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        பதிவு செய்கிறது...
                      </>
                    ) : (
                      "தானம் செய்ய பதிவு"
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
