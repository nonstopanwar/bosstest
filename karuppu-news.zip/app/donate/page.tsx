"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Check, CreditCard, IndianRupee, Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

// Donation amount options
const donationOptions = [
  { value: "100", label: "₹100" },
  { value: "500", label: "₹500" },
  { value: "1000", label: "₹1000" },
  { value: "2000", label: "₹2000" },
  { value: "5000", label: "₹5000" },
  { value: "custom", label: "பிற" },
]

export default function DonatePage() {
  const { toast } = useToast()
  const [selectedAmount, setSelectedAmount] = useState("500")
  const [customAmount, setCustomAmount] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleDonate = async () => {
    // Validate form
    if (!formData.name || !formData.email) {
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "பெயர் மற்றும் மின்னஞ்சல் கட்டாயமாகும்.",
      })
      return
    }

    const amount = selectedAmount === "custom" ? customAmount : selectedAmount
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "சரியான நன்கொடை தொகையை உள்ளிடவும்.",
      })
      return
    }

    setIsProcessing(true)

    try {
      // In a real implementation, you would integrate with Razorpay here
      // For now, we'll simulate the payment process and backend submission

      // Simulate payment processing
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Generate a fake payment ID
      const paymentId = "pay_" + Math.random().toString(36).substring(2, 15)

      // Submit donation details to backend
      const response = await fetch("/api/donate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          amount: selectedAmount === "custom" ? customAmount : selectedAmount,
          paymentId,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setIsSuccess(true)
        toast({
          title: "வெற்றி!",
          description: "உங்கள் நன்கொடை வெற்றிகரமாக பதிவு செய்யப்பட்டது. நன்றி!",
        })

        // Reset form after 5 seconds
        setTimeout(() => {
          setIsSuccess(false)
          setFormData({
            name: "",
            email: "",
            phone: "",
            message: "",
          })
          setSelectedAmount("500")
          setCustomAmount("")
        }, 5000)
      } else {
        toast({
          variant: "destructive",
          title: "பிழை!",
          description: data.message || "நன்கொடை பதிவில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.",
        })
      }
    } catch (error) {
      console.error("Donation error:", error)
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "சேவையகத்துடன் தொடர்பு கொள்ள முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="container mx-auto py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-4">நன்கொடை அளிக்க</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            உங்கள் நன்கொடை ஊழலுக்கு எதிரான போராட்டத்தில் எங்களுக்கு உதவும். கருப்பு எழுத்துக் கழகத்தின் செயல்பாடுகளுக்கு ஆதரவளிக்க நன்கொடை
            அளியுங்கள்.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <Card>
              <CardHeader>
                <CardTitle>நன்கொடை அளிக்க</CardTitle>
                <CardDescription>உங்கள் நன்கொடை தொகையைத் தேர்ந்தெடுக்கவும்</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <RadioGroup value={selectedAmount} onValueChange={setSelectedAmount} className="grid grid-cols-3 gap-4">
                  {donationOptions.map((option) => (
                    <div key={option.value}>
                      <RadioGroupItem value={option.value} id={`amount-${option.value}`} className="peer sr-only" />
                      <Label
                        htmlFor={`amount-${option.value}`}
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        {option.value === "custom" ? (
                          <span className="text-sm font-medium">பிற</span>
                        ) : (
                          <span className="text-xl font-semibold">{option.label}</span>
                        )}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>

                {selectedAmount === "custom" && (
                  <div className="space-y-2">
                    <Label htmlFor="custom-amount">தொகையை உள்ளிடவும்</Label>
                    <div className="relative">
                      <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="custom-amount"
                        type="number"
                        placeholder="தொகையை உள்ளிடவும்"
                        className="pl-10"
                        value={customAmount}
                        onChange={(e) => setCustomAmount(e.target.value)}
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="name">
                    பெயர் <span className="text-red-500">*</span>
                  </Label>
                  <Input id="name" placeholder="உங்கள் பெயர்" value={formData.name} onChange={handleChange} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">
                    மின்னஞ்சல் <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">தொலைபேசி எண்</Label>
                  <Input id="phone" placeholder="9876543210" value={formData.phone} onChange={handleChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">செய்தி (விருப்பம்)</Label>
                  <Textarea
                    id="message"
                    placeholder="உங்கள் செய்தியை இங்கே உள்ளிடவும்"
                    value={formData.message}
                    onChange={handleChange}
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  onClick={handleDonate}
                  className="w-full bg-primary hover:bg-primary/90"
                  disabled={isProcessing || (selectedAmount === "custom" && !customAmount)}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> செயலாக்கப்படுகிறது...
                    </>
                  ) : (
                    "நன்கொடை அளிக்க"
                  )}
                </Button>
              </CardFooter>

              {isSuccess && (
                <div className="mx-6 mb-6 p-3 bg-green-50 border border-green-200 rounded-md flex items-center gap-2 text-green-600">
                  <Check className="h-5 w-5" />
                  <span>நன்கொடை வெற்றிகரமாக செயலாக்கப்பட்டது. நன்றி!</span>
                </div>
              )}
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>உங்கள் நன்கொடை எவ்வாறு உதவுகிறது</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Check className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">ஊழல் எதிர்ப்பு விழிப்புணர்வு</h3>
                    <p className="text-sm text-muted-foreground">ஊழல் குறித்த விழிப்புணர்வு நிகழ்ச்சிகளை நடத்த உதவுகிறது</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Check className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">ஊழல் தொடர்பான ஆய்வுகள்</h3>
                    <p className="text-sm text-muted-foreground">ஊழல் தொடர்பான ஆய்வுகளை மேற்கொள்ள உதவுகிறது</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Check className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">செய்தி வெளியீடு</h3>
                    <p className="text-sm text-muted-foreground">ஊழல் தொடர்பான செய்திகளை வெளியிட உதவுகிறது</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Check className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">தொழில்நுட்ப மேம்பாடு</h3>
                    <p className="text-sm text-muted-foreground">எங்கள் தளத்தை மேம்படுத்த உதவுகிறது</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>பாதுகாப்பான பணப்பரிமாற்றம்</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  உங்கள் பணப்பரிமாற்றம் Razorpay மூலம் பாதுகாக்கப்படுகிறது. உங்கள் பண விவரங்கள் எங்களால் சேமிக்கப்படுவதில்லை.
                </p>
                <div className="flex items-center gap-2 mt-4">
                  <CreditCard className="h-5 w-5 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    அனைத்து முக்கிய கிரெடிட் மற்றும் டெபிட் கார்டுகள் ஏற்கப்படுகின்றன
                  </span>
                </div>
                <div className="flex items-center justify-center mt-4">
                  <Image
                    src="/placeholder.svg?key=1nxm3"
                    alt="Razorpay"
                    width={120}
                    height={40}
                    className="h-10 object-contain"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="bg-muted p-4 rounded-lg">
              <h3 className="font-medium mb-2">வரி சலுகை</h3>
              <p className="text-sm text-muted-foreground">
                உங்கள் நன்கொடைக்கு 80G பிரிவின் கீழ் வரி சலுகை பெறலாம். மேலும் விவரங்களுக்கு எங்களை தொடர்பு கொள்ளவும்.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
