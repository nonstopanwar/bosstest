import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarDays, Clock, ArrowRight, Facebook, Twitter, Instagram } from "lucide-react"

// Update the featuredNews array to include the election awareness campaign
const featuredNews = [
  {
    id: 1,
    title: "பல சிறுமிகளின் | பெண்களின் வாழ்வை இன்ஸ்டாகிராம் மூலம் சீரழித்த காமக் கொடூரனை கைது செய்யாமல் விட்ட காவல்துறை",
    excerpt:
      "உயிரிழந்த குழந்தையின் உறவுகளை மிரட்டிய கேணிக்கரை காவல் ஆய்வாளர் மீது நடவடிக்கை பாயுமா? அவனது instagram சாட் ஆயவுசெய்தபொது பல பெண்களின் | குழந்தைகளின் வாழக்கையை சீரழித்தது மட்டுமல்லாது பல அரசியல் பிரமுகர்களுக்கு அவனுடன் தொடர்புள்ளதாக தெரியவருகிறது.",
    date: "2025-05-10",
    time: "10:30 AM",
    category: "குற்றம்",
    image: "/crime-news-investigation.png",
  },
  {
    id: 6,
    title: "தேர்தலை பணம் கொடுக்காமல் நடத்தவும் வாக்களிக்க பணம் பெறுவது குற்றமெனவும் விழிப்புணர்வு பிரசாரம்",
    excerpt:
      "கருப்பு எழுத்துக் கழகம் சார்பில் தேர்தலை பணம் கொடுக்காமல் நடத்தவும் வாக்களிக்க பணம் பெறுவது குற்றமெனவும் விழிப்புணர்வு பிரசாரம் மேற்கொள்ளபட்டது.",
    date: "2025-05-15",
    time: "09:00 AM",
    category: "விழிப்புணர்வு",
    image: "/events/election-awareness-1.jpeg",
  },
  {
    id: 2,
    title: "ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம்",
    excerpt: "கருப்பு எழுத்துக் கழகம் சார்பில் ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம் நடைபெற்றது.",
    date: "2025-05-08",
    time: "10:30 AM",
    category: "நிகழ்வுகள்",
    image: "/anti-corruption-event.png",
  },
]

const recentNews = [
  {
    id: 4,
    title: "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல்",
    date: "2025-05-03",
    category: "சட்டம்",
  },
  {
    id: 5,
    title: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி",
    date: "2025-05-01",
    category: "நிகழ்வுகள்",
  },
  {
    id: 6,
    title: "ஊழல் குறித்த புகார்களை அளிக்க புதிய செயலி அறிமுகம்",
    date: "2025-04-28",
    category: "தொழில்நுட்பம்",
  },
  {
    id: 7,
    title: "ஊழல் ஒழிப்பு குறித்த கருத்துக்கணிப்பு முடிவுகள்",
    date: "2025-04-25",
    category: "ஆய்வு",
  },
]

export default function Home() {
  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-secondary to-primary text-white py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h1 className="text-3xl md:text-5xl font-bold leading-tight">ஊழலை ஒழிப்போம்! தேசத்தை நேசிப்போம்!</h1>
              <p className="text-lg md:text-xl">கருப்பு எழுத்துக் கழகம் ஊழலுக்கு எதிரான குரல் கொடுக்கும் தமிழ் செய்தி தளம்.</p>
              <div className="flex flex-wrap gap-4">
                <Link href="/register">
                  <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                    இணைந்திடுங்கள்
                  </Button>
                </Link>
                <Link href="/donate">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                    நன்கொடை அளிக்க
                  </Button>
                </Link>
                <div className="flex items-center gap-3 mt-4 md:mt-0">
                  <a
                    href="https://x.com/karuppuTv"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-white hover:text-gray-200"
                  >
                    <Twitter className="h-5 w-5" />
                  </a>
                  <a
                    href="https://www.facebook.com/karuppuezhutthu"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-white hover:text-gray-200"
                  >
                    <Facebook className="h-5 w-5" />
                  </a>
                  <a
                    href="https://www.instagram.com/karuppunews"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-white hover:text-gray-200"
                  >
                    <Instagram className="h-5 w-5" />
                  </a>
                </div>
              </div>
            </div>
            <div className="hidden md:block">
              <Image
                src="/anti-corruption-campaign.png"
                alt="Anti-corruption campaign"
                width={600}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured News */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">முக்கிய செய்திகள்</h2>
            <Link href="/news" className="text-primary hover:underline flex items-center">
              அனைத்து செய்திகளும் காண <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredNews.map((news) => (
              <Card key={news.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-48">
                  <Image src={news.image || "/placeholder.svg"} alt={news.title} fill className="object-cover" />
                  <Badge className="absolute top-2 right-2 bg-primary">{news.category}</Badge>
                </div>
                <CardHeader className="p-4">
                  <CardTitle className="text-xl line-clamp-2">{news.title}</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <CardDescription className="line-clamp-3 mb-4">{news.excerpt}</CardDescription>
                  <div className="flex items-center text-sm text-muted-foreground gap-4">
                    <div className="flex items-center">
                      <CalendarDays className="mr-1 h-4 w-4" />
                      {news.date}
                    </div>
                    <div className="flex items-center">
                      <Clock className="mr-1 h-4 w-4" />
                      {news.time}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Link href={`/news/${news.id}`}>
                    <Button variant="link" className="p-0 text-primary">
                      மேலும் படிக்க <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-12 bg-secondary text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <Image src="/images/logo.png" alt="Karuppu Logo" width={300} height={300} className="mx-auto md:mx-0" />
            </div>
            <div className="space-y-4">
              <h2 className="text-2xl md:text-3xl font-bold">கருப்பு எழுத்துக் கழகம் பற்றி</h2>
              <p className="text-lg">
                கருப்பு எழுத்துக் கழகம் என்பது ஊழலுக்கு எதிரான குரல் கொடுக்கும் ஒரு தமிழ் செய்தி அமைப்பாகும். நாங்கள் ஊழல் குறித்த செய்திகளை
                வெளிப்படுத்தி, ஊழலுக்கு எதிரான விழிப்புணர்வை ஏற்படுத்துகிறோம்.
              </p>
              <p className="text-lg">
                எங்கள் குறிக்கோள் ஊழலற்ற சமூகத்தை உருவாக்குவதாகும். உங்கள் ஆதரவுடன், நாங்கள் ஊழலுக்கு எதிரான போராட்டத்தில் வெற்றி பெறுவோம்.
              </p>
              <Link href="/about">
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  மேலும் அறிய
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Recent News & Join Us */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <h2 className="text-2xl font-bold mb-6">சமீபத்திய செய்திகள்</h2>
              <div className="space-y-4">
                {recentNews.map((news) => (
                  <div key={news.id} className="border-b pb-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <Link href={`/news/${news.id}`} className="text-lg font-medium hover:text-primary">
                          {news.title}
                        </Link>
                        <div className="flex items-center text-sm text-muted-foreground mt-1">
                          <CalendarDays className="mr-1 h-4 w-4" />
                          {news.date}
                          <Badge variant="outline" className="ml-2">
                            {news.category}
                          </Badge>
                        </div>
                      </div>
                      <Link href={`/news/${news.id}`}>
                        <Button variant="ghost" size="icon" className="text-primary">
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-primary/10 p-6 rounded-lg">
              <h2 className="text-2xl font-bold mb-4">எங்களுடன் இணையுங்கள்</h2>
              <p className="mb-4">
                ஊழலுக்கு எதிரான போராட்டத்தில் எங்களுடன் இணைந்து பயணிக்க விரும்புகிறீர்களா? இப்போதே பதிவு செய்து, எங்கள் குடும்பத்தில்
                இணையுங்கள்.
              </p>
              <div className="space-y-4">
                <Link href="/register">
                  <Button className="w-full bg-primary hover:bg-primary/90">இப்போதே பதிவு செய்ய</Button>
                </Link>
                <Link href="/donate">
                  <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary/10">
                    நன்கொடை அளிக்க
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
