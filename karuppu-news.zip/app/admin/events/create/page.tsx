"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Upload, X, Loader2, Plus } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import AdminHeader from "@/components/admin/admin-header"

export default function CreateEventPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [previewImages, setPreviewImages] = useState<string[]>([])
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    content: "",
    date: "",
    location: "",
    category: "",
    featured: false,
    status: "upcoming",
    images: [] as File[],
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      [name]: checked,
    }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const newImages = Array.from(files)
      setFormData((prev) => ({
        ...prev,
        images: [...prev.images, ...newImages],
      }))

      // Create preview URLs
      const newPreviews: string[] = []
      newImages.forEach((file) => {
        const reader = new FileReader()
        reader.onloadend = () => {
          newPreviews.push(reader.result as string)
          if (newPreviews.length === newImages.length) {
            setPreviewImages((prev) => [...prev, ...newPreviews])
          }
        }
        reader.readAsDataURL(file)
      })
    }
  }

  const removeImage = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }))
    setPreviewImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.title || !formData.content || !formData.date || !formData.location || !formData.category) {
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "தலைப்பு, உள்ளடக்கம், தேதி, இடம் மற்றும் வகை ஆகியவை அவசியம்.",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, this would be an API call to save the event
      // For now, we'll simulate a successful save
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "வெற்றி!",
        description: "நிகழ்வு வெற்றிகரமாக சேமிக்கப்பட்டது.",
      })

      router.push("/admin/events")
    } catch (error) {
      console.error("Error saving event:", error)
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "நிகழ்வைச் சேமிப்பதில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("karuppu_admin")
    toast({
      title: "வெற்றி!",
      description: "வெற்றிகரமாக வெளியேறினீர்கள்.",
    })
    router.push("/admin/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader adminEmail="editor@karuppu.in" onLogout={handleLogout} />

      <main className="container mx-auto py-8 px-4">
        <div className="flex items-center gap-2 mb-6">
          <Link href="/admin/events" className="text-primary hover:underline flex items-center">
            <ArrowLeft className="mr-1 h-4 w-4" />
            திரும்பிச் செல்ல
          </Link>
          <h1 className="text-3xl font-bold">புதிய நிகழ்வு உருவாக்க</h1>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">
                      தலைப்பு <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="நிகழ்வு தலைப்பை உள்ளிடவும்"
                      value={formData.title}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">சுருக்கம்</Label>
                    <Textarea
                      id="description"
                      name="description"
                      placeholder="நிகழ்வின் சுருக்கத்தை உள்ளிடவும்"
                      value={formData.description}
                      onChange={handleChange}
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="content">
                      உள்ளடக்கம் <span className="text-red-500">*</span>
                    </Label>
                    <Textarea
                      id="content"
                      name="content"
                      placeholder="நிகழ்வின் முழு விவரங்களை உள்ளிடவும்"
                      value={formData.content}
                      onChange={handleChange}
                      rows={15}
                      required
                    />
                    <p className="text-xs text-muted-foreground">
                      HTML குறியீடுகளைப் பயன்படுத்தலாம் (எ.கா. &lt;p&gt;, &lt;h3&gt;, &lt;ul&gt;, &lt;li&gt;)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <Label>நிகழ்வு படங்கள்</Label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {previewImages.map((image, index) => (
                        <div key={index} className="relative">
                          <Image
                            src={image || "/placeholder.svg"}
                            alt={`Preview ${index + 1}`}
                            width={300}
                            height={200}
                            className="w-full h-40 object-cover rounded-md"
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            className="absolute top-2 right-2"
                            onClick={() => removeImage(index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}

                      <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center gap-2 hover:bg-muted/50 cursor-pointer transition-colors h-40">
                        <Upload className="h-8 w-8 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">படத்தைப் பதிவேற்ற இங்கே கிளிக் செய்யவும்</p>
                        <Input
                          id="images"
                          type="file"
                          accept="image/*"
                          multiple
                          className="hidden"
                          onChange={handleImageChange}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => document.getElementById("images")?.click()}
                        >
                          <Plus className="mr-2 h-4 w-4" />
                          படம் சேர்க்க
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">
                      தேதி <span className="text-red-500">*</span>
                    </Label>
                    <Input id="date" name="date" type="date" value={formData.date} onChange={handleChange} required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">
                      இடம் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="location"
                      name="location"
                      placeholder="நிகழ்வு நடைபெறும் இடம்"
                      value={formData.location}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">
                      வகை <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      name="category"
                      value={formData.category}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="வகையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="சமூக சேவை">சமூக சேவை</SelectItem>
                        <SelectItem value="விழிப்புணர்வு">விழிப்புணர்வு</SelectItem>
                        <SelectItem value="விவாதம்">விவாதம்</SelectItem>
                        <SelectItem value="பேரணி">பேரணி</SelectItem>
                        <SelectItem value="கலந்துரையாடல்">கலந்துரையாடல்</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="status">
                      நிலை <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      name="status"
                      value={formData.status}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="நிலையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="upcoming">வரவிருக்கிறது</SelectItem>
                        <SelectItem value="ongoing">நடைபெறுகிறது</SelectItem>
                        <SelectItem value="completed">முடிந்தது</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2 pt-2">
                    <Checkbox
                      id="featured"
                      checked={formData.featured}
                      onCheckedChange={(checked) => handleCheckboxChange("featured", checked as boolean)}
                    />
                    <Label
                      htmlFor="featured"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      சிறப்பு நிகழ்வாக காட்டு
                    </Label>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-4">
                <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      சேமிக்கிறது...
                    </>
                  ) : (
                    "சேமி"
                  )}
                </Button>
                <Link href="/admin/events">
                  <Button type="button" variant="outline" className="flex-1">
                    ரத்து செய்
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </form>
      </main>
    </div>
  )
}
