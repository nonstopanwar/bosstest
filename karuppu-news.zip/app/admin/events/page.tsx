"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { PlusCircle, Search, Edit, Trash2, Eye, ArrowUpDown, ChevronLeft, ChevronRight } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import AdminHeader from "@/components/admin/admin-header"
import { useRouter } from "next/navigation"

// Sample events data
const allEvents = [
  {
    id: 6,
    title: "தேர்தலை பணம் கொடுக்காமல் நடத்தவும் வாக்களிக்க பணம் பெறுவது குற்றமெனவும் விழிப்புணர்வு பிரசாரம்",
    date: "2025-05-15",
    location: "சென்னை கடற்கரை, தமிழ்நாடு",
    category: "விழிப்புணர்வு",
    featured: true,
    status: "upcoming",
  },
  {
    id: 1,
    title: "இரத்த தான முகாம் மற்றும் மருத்துவ முகாம்",
    date: "2025-04-15",
    location: "சென்னை, தமிழ்நாடு",
    category: "சமூக சேவை",
    featured: true,
    status: "completed",
  },
  {
    id: 2,
    title: "இலஞ்சம் குறித்த விழிப்புணர்வு - மாணவர்களுக்கான நிகழ்ச்சி",
    date: "2025-04-10",
    location: "திருச்சி, தமிழ்நாடு",
    category: "விழிப்புணர்வு",
    featured: true,
    status: "completed",
  },
  {
    id: 3,
    title: "தமிழக இலஞ்ச ஒழிப்புதுறை குறித்த விவாதம்",
    date: "2025-05-05",
    location: "சென்னை, தமிழ்நாடு",
    category: "விவாதம்",
    featured: false,
    status: "completed",
  },
  {
    id: 4,
    title: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி",
    date: "2025-03-28",
    location: "மதுரை, தமிழ்நாடு",
    category: "பேரணி",
    featured: false,
    status: "completed",
  },
  {
    id: 5,
    title: "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல்",
    date: "2025-03-15",
    location: "கோயம்புத்தூர், தமிழ்நாடு",
    category: "கலந்துரையாடல்",
    featured: false,
    status: "completed",
  },
]

export default function AdminEventsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sortBy, setSortBy] = useState("date")
  const [sortOrder, setSortOrder] = useState("desc")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const handleLogout = () => {
    localStorage.removeItem("karuppu_admin")
    toast({
      title: "வெற்றி!",
      description: "வெற்றிகரமாக வெளியேறினீர்கள்.",
    })
    router.push("/admin/login")
  }

  const handleDelete = (id: number) => {
    // In a real app, this would be an API call
    toast({
      title: "நிகழ்வு நீக்கப்பட்டது",
      description: `நிகழ்வு ID: ${id} வெற்றிகரமாக நீக்கப்பட்டது.`,
    })
  }

  // Filter and sort events
  const filteredEvents = allEvents
    .filter((event) => {
      const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = categoryFilter === "all" || event.category === categoryFilter
      const matchesStatus = statusFilter === "all" || event.status === statusFilter
      return matchesSearch && matchesCategory && matchesStatus
    })
    .sort((a, b) => {
      if (sortBy === "date") {
        return sortOrder === "asc"
          ? new Date(a.date).getTime() - new Date(b.date).getTime()
          : new Date(b.date).getTime() - new Date(a.date).getTime()
      } else if (sortBy === "title") {
        return sortOrder === "asc" ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title)
      } else if (sortBy === "location") {
        return sortOrder === "asc" ? a.location.localeCompare(b.location) : b.location.localeCompare(a.location)
      }
      return 0
    })

  // Pagination
  const totalPages = Math.ceil(filteredEvents.length / itemsPerPage)
  const paginatedEvents = filteredEvents.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader adminEmail="editor@karuppu.in" onLogout={handleLogout} />

      <main className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">நிகழ்வுகள் நிர்வாகம்</h1>
          <Link href="/admin/events/create">
            <Button className="bg-primary hover:bg-primary/90">
              <PlusCircle className="mr-2 h-4 w-4" />
              புதிய நிகழ்வு
            </Button>
          </Link>
        </div>

        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="நிகழ்வுகளைத் தேட..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="வகை" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">அனைத்து வகைகளும்</SelectItem>
                    <SelectItem value="சமூக சேவை">சமூக சேவை</SelectItem>
                    <SelectItem value="விழிப்புணர்வு">விழிப்புணர்வு</SelectItem>
                    <SelectItem value="விவாதம்">விவாதம்</SelectItem>
                    <SelectItem value="பேரணி">பேரணி</SelectItem>
                    <SelectItem value="கலந்துரையாடல்">கலந்துரையாடல்</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="நிலை" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">அனைத்து நிலைகளும்</SelectItem>
                    <SelectItem value="upcoming">வரவிருக்கிறது</SelectItem>
                    <SelectItem value="ongoing">நடைபெறுகிறது</SelectItem>
                    <SelectItem value="completed">முடிந்தது</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="வரிசைப்படுத்து" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date">தேதி</SelectItem>
                    <SelectItem value="title">தலைப்பு</SelectItem>
                    <SelectItem value="location">இடம்</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">ID</TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "title") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("title")
                          setSortOrder("asc")
                        }
                      }}
                    >
                      தலைப்பு
                      {sortBy === "title" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "date") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("date")
                          setSortOrder("desc")
                        }
                      }}
                    >
                      தேதி
                      {sortBy === "date" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "location") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("location")
                          setSortOrder("asc")
                        }
                      }}
                    >
                      இடம்
                      {sortBy === "location" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead>வகை</TableHead>
                  <TableHead>நிலை</TableHead>
                  <TableHead className="text-right">செயல்கள்</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedEvents.length > 0 ? (
                  paginatedEvents.map((event) => (
                    <TableRow key={event.id}>
                      <TableCell>{event.id}</TableCell>
                      <TableCell className="font-medium max-w-[300px] truncate">
                        {event.title}
                        {event.featured && <Badge className="ml-2 bg-primary">சிறப்பு</Badge>}
                      </TableCell>
                      <TableCell>{event.date}</TableCell>
                      <TableCell>{event.location}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{event.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            event.status === "upcoming"
                              ? "default"
                              : event.status === "ongoing"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {event.status === "upcoming"
                            ? "வரவிருக்கிறது"
                            : event.status === "ongoing"
                              ? "நடைபெறுகிறது"
                              : "முடிந்தது"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Link href={`/events/${event.id}`} target="_blank">
                            <Button variant="ghost" size="icon">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </Link>
                          <Link href={`/admin/events/edit/${event.id}`}>
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </Link>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(event.id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-4">
                      நிகழ்வுகள் எதுவும் கிடைக்கவில்லை
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {totalPages > 1 && (
          <div className="flex justify-center mt-4">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm">
                பக்கம் {currentPage} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
