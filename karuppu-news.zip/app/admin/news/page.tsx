"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { PlusCircle, Search, Edit, Trash2, Eye, ArrowUpDown, ChevronLeft, ChevronRight } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import AdminHeader from "@/components/admin/admin-header"
import { useRouter } from "next/navigation"

// Sample news data
const allNews = [
  {
    id: 1,
    title: "பல சிறுமிகளின் | பெண்களின் வாழ்வை இன்ஸ்டாகிராம் மூலம் சீரழித்த காமக் கொடூரனை கைது செய்யாமல் விட்ட காவல்துறை",
    date: "2025-05-10",
    category: "குற்றம்",
    views: 1245,
    featured: true,
    status: "published",
  },
  {
    id: 2,
    title: "ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம்",
    date: "2025-05-08",
    category: "நிகழ்வுகள்",
    views: 856,
    featured: true,
    status: "published",
  },
  {
    id: 3,
    title: "ஊழல் புகார் எண் அறிமுகம்: 24 மணி நேரமும் செயல்படும்",
    date: "2025-05-05",
    category: "அறிவிப்புகள்",
    views: 723,
    featured: false,
    status: "published",
  },
  {
    id: 4,
    title: "ஊழல் ஒழிப்பு போராட்டம்: மாணவர்கள் பங்கேற்பு",
    date: "2025-05-03",
    category: "செய்திகள்",
    views: 645,
    featured: false,
    status: "published",
  },
  {
    id: 5,
    title: "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல்",
    date: "2025-05-01",
    category: "சட்டம்",
    views: 532,
    featured: false,
    status: "published",
  },
  {
    id: 6,
    title: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி",
    date: "2025-04-28",
    category: "நிகழ்வுகள்",
    views: 478,
    featured: false,
    status: "published",
  },
]

export default function AdminNewsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sortBy, setSortBy] = useState("date")
  const [sortOrder, setSortOrder] = useState("desc")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const handleLogout = () => {
    localStorage.removeItem("karuppu_admin")
    toast({
      title: "வெற்றி!",
      description: "வெற்றிகரமாக வெளியேறினீர்கள்.",
    })
    router.push("/admin/login")
  }

  const handleDelete = (id: number) => {
    // In a real app, this would be an API call
    toast({
      title: "செய்தி நீக்கப்பட்டது",
      description: `செய்தி ID: ${id} வெற்றிகரமாக நீக்கப்பட்டது.`,
    })
  }

  // Filter and sort news
  const filteredNews = allNews
    .filter((news) => {
      const matchesSearch = news.title.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = categoryFilter === "all" || news.category === categoryFilter
      const matchesStatus = statusFilter === "all" || news.status === statusFilter
      return matchesSearch && matchesCategory && matchesStatus
    })
    .sort((a, b) => {
      if (sortBy === "date") {
        return sortOrder === "asc"
          ? new Date(a.date).getTime() - new Date(b.date).getTime()
          : new Date(b.date).getTime() - new Date(a.date).getTime()
      } else if (sortBy === "views") {
        return sortOrder === "asc" ? a.views - b.views : b.views - a.views
      } else if (sortBy === "title") {
        return sortOrder === "asc" ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title)
      }
      return 0
    })

  // Pagination
  const totalPages = Math.ceil(filteredNews.length / itemsPerPage)
  const paginatedNews = filteredNews.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader adminEmail="editor@karuppu.in" onLogout={handleLogout} />

      <main className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">செய்திகள் நிர்வாகம்</h1>
          <Link href="/admin/news/create">
            <Button className="bg-primary hover:bg-primary/90">
              <PlusCircle className="mr-2 h-4 w-4" />
              புதிய செய்தி
            </Button>
          </Link>
        </div>

        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="செய்திகளைத் தேட..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="வகை" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">அனைத்து வகைகளும்</SelectItem>
                    <SelectItem value="குற்றம்">குற்றம்</SelectItem>
                    <SelectItem value="நிகழ்வுகள்">நிகழ்வுகள்</SelectItem>
                    <SelectItem value="அறிவிப்புகள்">அறிவிப்புகள்</SelectItem>
                    <SelectItem value="செய்திகள்">செய்திகள்</SelectItem>
                    <SelectItem value="சட்டம்">சட்டம்</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="நிலை" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">அனைத்து நிலைகளும்</SelectItem>
                    <SelectItem value="published">வெளியிடப்பட்டது</SelectItem>
                    <SelectItem value="draft">வரைவு</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="வரிசைப்படுத்து" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date">தேதி</SelectItem>
                    <SelectItem value="title">தலைப்பு</SelectItem>
                    <SelectItem value="views">பார்வைகள்</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">ID</TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "title") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("title")
                          setSortOrder("asc")
                        }
                      }}
                    >
                      தலைப்பு
                      {sortBy === "title" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "date") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("date")
                          setSortOrder("desc")
                        }
                      }}
                    >
                      தேதி
                      {sortBy === "date" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead>வகை</TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "views") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("views")
                          setSortOrder("desc")
                        }
                      }}
                    >
                      பார்வைகள்
                      {sortBy === "views" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead>நிலை</TableHead>
                  <TableHead className="text-right">செயல்கள்</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedNews.length > 0 ? (
                  paginatedNews.map((news) => (
                    <TableRow key={news.id}>
                      <TableCell>{news.id}</TableCell>
                      <TableCell className="font-medium max-w-[300px] truncate">
                        {news.title}
                        {news.featured && <Badge className="ml-2 bg-primary">சிறப்பு</Badge>}
                      </TableCell>
                      <TableCell>{news.date}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{news.category}</Badge>
                      </TableCell>
                      <TableCell>{news.views}</TableCell>
                      <TableCell>
                        <Badge variant={news.status === "published" ? "default" : "secondary"}>
                          {news.status === "published" ? "வெளியிடப்பட்டது" : "வரைவு"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Link href={`/news/${news.id}`} target="_blank">
                            <Button variant="ghost" size="icon">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </Link>
                          <Link href={`/admin/news/edit/${news.id}`}>
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </Link>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(news.id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-4">
                      செய்திகள் எதுவும் கிடைக்கவில்லை
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {totalPages > 1 && (
          <div className="flex justify-center mt-4">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm">
                பக்கம் {currentPage} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
