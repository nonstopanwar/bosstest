"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Upload, X, Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import AdminHeader from "@/components/admin/admin-header"

export default function CreateNewsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [previewImage, setPreviewImage] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    excerpt: "",
    content: "",
    category: "",
    tags: "",
    featured: false,
    status: "published",
    image: null as File | null,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      [name]: checked,
    }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFormData((prev) => ({
        ...prev,
        image: file,
      }))

      // Create preview URL
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeImage = () => {
    setFormData((prev) => ({
      ...prev,
      image: null,
    }))
    setPreviewImage(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.title || !formData.content || !formData.category) {
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "தலைப்பு, உள்ளடக்கம் மற்றும் வகை ஆகியவை அவசியம்.",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, this would be an API call to save the news
      // For now, we'll simulate a successful save
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "வெற்றி!",
        description: "செய்தி வெற்றிகரமாக சேமிக்கப்பட்டது.",
      })

      router.push("/admin/news")
    } catch (error) {
      console.error("Error saving news:", error)
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "செய்தியைச் சேமிப்பதில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("karuppu_admin")
    toast({
      title: "வெற்றி!",
      description: "வெற்றிகரமாக வெளியேறினீர்கள்.",
    })
    router.push("/admin/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader adminEmail="editor@karuppu.in" onLogout={handleLogout} />

      <main className="container mx-auto py-8 px-4">
        <div className="flex items-center gap-2 mb-6">
          <Link href="/admin/news" className="text-primary hover:underline flex items-center">
            <ArrowLeft className="mr-1 h-4 w-4" />
            திரும்பிச் செல்ல
          </Link>
          <h1 className="text-3xl font-bold">புதிய செய்தி உருவாக்க</h1>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">
                      தலைப்பு <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="செய்தி தலைப்பை உள்ளிடவும்"
                      value={formData.title}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="excerpt">சுருக்கம்</Label>
                    <Textarea
                      id="excerpt"
                      name="excerpt"
                      placeholder="செய்தியின் சுருக்கத்தை உள்ளிடவும்"
                      value={formData.excerpt}
                      onChange={handleChange}
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="content">
                      உள்ளடக்கம் <span className="text-red-500">*</span>
                    </Label>
                    <Textarea
                      id="content"
                      name="content"
                      placeholder="செய்தியின் முழு உள்ளடக்கத்தை உள்ளிடவும்"
                      value={formData.content}
                      onChange={handleChange}
                      rows={15}
                      required
                    />
                    <p className="text-xs text-muted-foreground">
                      HTML குறியீடுகளைப் பயன்படுத்தலாம் (எ.கா. &lt;p&gt;, &lt;h3&gt;, &lt;ul&gt;, &lt;li&gt;)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <Label>முதன்மை படம்</Label>
                    {previewImage ? (
                      <div className="relative">
                        <Image
                          src={previewImage || "/placeholder.svg"}
                          alt="Preview"
                          width={600}
                          height={300}
                          className="w-full h-64 object-cover rounded-md"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2"
                          onClick={removeImage}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center gap-2 hover:bg-muted/50 cursor-pointer transition-colors">
                        <Upload className="h-8 w-8 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                          படத்தைப் பதிவேற்ற இங்கே கிளிக் செய்யவும் அல்லது இழுத்து விடவும்
                        </p>
                        <Input
                          id="image"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleImageChange}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => document.getElementById("image")?.click()}
                        >
                          படத்தைத் தேர்ந்தெடுக்கவும்
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardContent className="p-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="status">
                      நிலை <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      name="status"
                      value={formData.status}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="நிலையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="published">வெளியிடு</SelectItem>
                        <SelectItem value="draft">வரைவாக சேமி</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">
                      வகை <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      name="category"
                      value={formData.category}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="வகையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="குற்றம்">குற்றம்</SelectItem>
                        <SelectItem value="நிகழ்வுகள்">நிகழ்வுகள்</SelectItem>
                        <SelectItem value="அறிவிப்புகள்">அறிவிப்புகள்</SelectItem>
                        <SelectItem value="செய்திகள்">செய்திகள்</SelectItem>
                        <SelectItem value="சட்டம்">சட்டம்</SelectItem>
                        <SelectItem value="அரசியல்">அரசியல்</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tags">குறிச்சொற்கள்</Label>
                    <Input
                      id="tags"
                      name="tags"
                      placeholder="குறிச்சொற்களை காற்புள்ளியால் பிரிக்கவும்"
                      value={formData.tags}
                      onChange={handleChange}
                    />
                    <p className="text-xs text-muted-foreground">
                      குறிச்சொற்களை காற்புள்ளியால் பிரிக்கவும் (எ.கா. ஊழல், காவல்துறை, அரசியல்)
                    </p>
                  </div>

                  <div className="flex items-center space-x-2 pt-2">
                    <Checkbox
                      id="featured"
                      checked={formData.featured}
                      onCheckedChange={(checked) => handleCheckboxChange("featured", checked as boolean)}
                    />
                    <Label
                      htmlFor="featured"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      சிறப்பு செய்தியாக காட்டு
                    </Label>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-4">
                <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      சேமிக்கிறது...
                    </>
                  ) : (
                    "சேமி"
                  )}
                </Button>
                <Link href="/admin/news">
                  <Button type="button" variant="outline" className="flex-1">
                    ரத்து செய்
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </form>
      </main>
    </div>
  )
}
