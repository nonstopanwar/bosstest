"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import AdminHeader from "@/components/admin/admin-header"

export default function AdminSettingsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [siteSettings, setSiteSettings] = useState({
    siteName: "கருப்பு எழுத்துக் கழகம்",
    siteDescription: "ஊழலுக்கு எதிரான குரல் கொடுக்கும் தமிழ் செய்தி அமைப்பு",
    contactEmail: "hello@karuppu.in",
    contactPhone: "+91 7826994499",
    enableComments: true,
    enableRegistration: true,
    enableDonations: true,
    enableNotifications: true,
  })

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setPasswordData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleSiteSettingsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setSiteSettings((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleToggleChange = (id: string, checked: boolean) => {
    setSiteSettings((prev) => ({
      ...prev,
      [id]: checked,
    }))
  }

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "அனைத்து புலங்களையும் நிரப்பவும்.",
      })
      return
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "புதிய கடவுச்சொல் மற்றும் உறுதிப்படுத்தல் கடவுச்சொல் பொருந்தவில்லை.",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, this would be an API call to change the password
      // For now, we'll simulate a successful password change
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "வெற்றி!",
        description: "கடவுச்சொல் வெற்றிகரமாக மாற்றப்பட்டது.",
      })

      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      })
    } catch (error) {
      console.error("Error changing password:", error)
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "கடவுச்சொல் மாற்றத்தில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSiteSettingsSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    setIsSubmitting(true)

    try {
      // In a real app, this would be an API call to save the site settings
      // For now, we'll simulate a successful save
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "வெற்றி!",
        description: "தள அமைப்புகள் வெற்றிகரமாக சேமிக்கப்பட்டன.",
      })
    } catch (error) {
      console.error("Error saving site settings:", error)
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "தள அமைப்புகளைச் சேமிப்பதில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("karuppu_admin")
    toast({
      title: "வெற்றி!",
      description: "வெற்றிகரமாக வெளியேறினீர்கள்.",
    })
    router.push("/admin/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader adminEmail="editor@karuppu.in" onLogout={handleLogout} />

      <main className="container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">அமைப்புகள்</h1>

        <Tabs defaultValue="account">
          <TabsList className="mb-6">
            <TabsTrigger value="account">கணக்கு</TabsTrigger>
            <TabsTrigger value="site">தள அமைப்புகள்</TabsTrigger>
          </TabsList>

          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>கணக்கு அமைப்புகள்</CardTitle>
                <CardDescription>உங்கள் கணக்கு விவரங்களை நிர்வகிக்கவும்</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">கணக்கு விவரங்கள்</h3>
                  <p className="text-sm text-muted-foreground mb-4">உங்கள் கணக்கு விவரங்களைப் பார்க்கவும்</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">மின்னஞ்சல்</Label>
                      <Input id="email" value="editor@karuppu.in" disabled />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="role">பங்கு</Label>
                      <Input id="role" value="ஆசிரியர்" disabled />
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium">கடவுச்சொல் மாற்றம்</h3>
                  <p className="text-sm text-muted-foreground mb-4">உங்கள் கடவுச்சொல்லை மாற்றவும்</p>

                  <form onSubmit={handlePasswordSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword">தற்போதைய கடவுச்சொல்</Label>
                      <Input
                        id="currentPassword"
                        type="password"
                        value={passwordData.currentPassword}
                        onChange={handlePasswordChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">புதிய கடவுச்சொல்</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={passwordData.newPassword}
                        onChange={handlePasswordChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">கடவுச்சொல்லை உறுதிப்படுத்தவும்</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={passwordData.confirmPassword}
                        onChange={handlePasswordChange}
                      />
                    </div>
                    <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          சேமிக்கிறது...
                        </>
                      ) : (
                        "கடவுச்சொல்லை மாற்று"
                      )}
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="site">
            <Card>
              <CardHeader>
                <CardTitle>தள அமைப்புகள்</CardTitle>
                <CardDescription>தள அமைப்புகளை நிர்வகிக்கவும்</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSiteSettingsSubmit} className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium">அடிப்படை அமைப்புகள்</h3>
                    <p className="text-sm text-muted-foreground mb-4">தளத்தின் அடிப்படை அமைப்புகளை மாற்றவும்</p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="siteName">தள பெயர்</Label>
                        <Input id="siteName" value={siteSettings.siteName} onChange={handleSiteSettingsChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="siteDescription">தள விளக்கம்</Label>
                        <Input
                          id="siteDescription"
                          value={siteSettings.siteDescription}
                          onChange={handleSiteSettingsChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="contactEmail">தொடர்பு மின்னஞ்சல்</Label>
                        <Input
                          id="contactEmail"
                          value={siteSettings.contactEmail}
                          onChange={handleSiteSettingsChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="contactPhone">தொடர்பு தொலைபேசி</Label>
                        <Input
                          id="contactPhone"
                          value={siteSettings.contactPhone}
                          onChange={handleSiteSettingsChange}
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-medium">அம்சங்கள்</h3>
                    <p className="text-sm text-muted-foreground mb-4">தளத்தின் அம்சங்களை இயக்கவும் அல்லது முடக்கவும்</p>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="enableComments" className="text-base">
                            கருத்துகள்
                          </Label>
                          <p className="text-sm text-muted-foreground">செய்திகளில் கருத்துகளை அனுமதிக்கவும்</p>
                        </div>
                        <Switch
                          id="enableComments"
                          checked={siteSettings.enableComments}
                          onCheckedChange={(checked) => handleToggleChange("enableComments", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="enableRegistration" className="text-base">
                            பயனர் பதிவு
                          </Label>
                          <p className="text-sm text-muted-foreground">புதிய பயனர் பதிவுகளை அனுமதிக்கவும்</p>
                        </div>
                        <Switch
                          id="enableRegistration"
                          checked={siteSettings.enableRegistration}
                          onCheckedChange={(checked) => handleToggleChange("enableRegistration", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="enableDonations" className="text-base">
                            நன்கொடைகள்
                          </Label>
                          <p className="text-sm text-muted-foreground">நன்கொடை அம்சத்தை இயக்கவும்</p>
                        </div>
                        <Switch
                          id="enableDonations"
                          checked={siteSettings.enableDonations}
                          onCheckedChange={(checked) => handleToggleChange("enableDonations", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="enableNotifications" className="text-base">
                            அறிவிப்புகள்
                          </Label>
                          <p className="text-sm text-muted-foreground">மின்னஞ்சல் அறிவிப்புகளை இயக்கவும்</p>
                        </div>
                        <Switch
                          id="enableNotifications"
                          checked={siteSettings.enableNotifications}
                          onCheckedChange={(checked) => handleToggleChange("enableNotifications", checked)}
                        />
                      </div>
                    </div>
                  </div>

                  <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        சேமிக்கிறது...
                      </>
                    ) : (
                      "அமைப்புகளைச் சேமி"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
