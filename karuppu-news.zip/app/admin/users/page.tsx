"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Edit, Trash2, UserPlus, ArrowUpDown, ChevronLeft, ChevronRight } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import AdminHeader from "@/components/admin/admin-header"

// Sample users data
const allUsers = [
  {
    id: 1,
    name: "ராஜேந்திரன்",
    email: "rajendran@example.com",
    role: "reporter",
    district: "சென்னை",
    status: "active",
    kycStatus: "verified",
    registeredDate: "2025-01-15",
  },
  {
    id: 2,
    name: "கவிதா",
    email: "kavitha@example.com",
    role: "organizer",
    district: "மதுரை",
    status: "active",
    kycStatus: "verified",
    registeredDate: "2025-02-10",
  },
  {
    id: 3,
    name: "சுரேஷ்",
    email: "suresh@example.com",
    role: "reporter",
    district: "கோயம்புத்தூர்",
    status: "active",
    kycStatus: "verified",
    registeredDate: "2025-02-20",
  },
  {
    id: 4,
    name: "அனிதா",
    email: "anitha@example.com",
    role: "reporter",
    district: "திருச்சி",
    status: "inactive",
    kycStatus: "pending",
    registeredDate: "2025-03-05",
  },
  {
    id: 5,
    name: "கார்த்திக்",
    email: "karthik@example.com",
    role: "organizer",
    district: "சேலம்",
    status: "active",
    kycStatus: "verified",
    registeredDate: "2025-03-15",
  },
  {
    id: 6,
    name: "பிரியா",
    email: "priya@example.com",
    role: "reporter",
    district: "திருநெல்வேலி",
    status: "pending",
    kycStatus: "pending",
    registeredDate: "2025-04-01",
  },
]

export default function AdminUsersPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [roleFilter, setRoleFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sortBy, setSortBy] = useState("registeredDate")
  const [sortOrder, setSortOrder] = useState("desc")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const handleLogout = () => {
    localStorage.removeItem("karuppu_admin")
    toast({
      title: "வெற்றி!",
      description: "வெற்றிகரமாக வெளியேறினீர்கள்.",
    })
    router.push("/admin/login")
  }

  const handleDelete = (id: number) => {
    // In a real app, this would be an API call
    toast({
      title: "பயனர் நீக்கப்பட்டார்",
      description: `பயனர் ID: ${id} வெற்றிகரமாக நீக்கப்பட்டார்.`,
    })
  }

  // Filter and sort users
  const filteredUsers = allUsers
    .filter((user) => {
      const matchesSearch =
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesRole = roleFilter === "all" || user.role === roleFilter
      const matchesStatus = statusFilter === "all" || user.status === statusFilter
      return matchesSearch && matchesRole && matchesStatus
    })
    .sort((a, b) => {
      if (sortBy === "registeredDate") {
        return sortOrder === "asc"
          ? new Date(a.registeredDate).getTime() - new Date(b.registeredDate).getTime()
          : new Date(b.registeredDate).getTime() - new Date(a.registeredDate).getTime()
      } else if (sortBy === "name") {
        return sortOrder === "asc" ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name)
      } else if (sortBy === "email") {
        return sortOrder === "asc" ? a.email.localeCompare(b.email) : b.email.localeCompare(a.email)
      }
      return 0
    })

  // Pagination
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage)
  const paginatedUsers = filteredUsers.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader adminEmail="editor@karuppu.in" onLogout={handleLogout} />

      <main className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">பயனர்கள் நிர்வாகம்</h1>
          <Button className="bg-primary hover:bg-primary/90">
            <UserPlus className="mr-2 h-4 w-4" />
            புதிய பயனர்
          </Button>
        </div>

        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="பயனர்களைத் தேட..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div>
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="பங்கு" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">அனைத்து பங்குகளும்</SelectItem>
                    <SelectItem value="reporter">செய்தியாளர்</SelectItem>
                    <SelectItem value="organizer">அமைப்பாளர்</SelectItem>
                    <SelectItem value="admin">நிர்வாகி</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="நிலை" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">அனைத்து நிலைகளும்</SelectItem>
                    <SelectItem value="active">செயலில் உள்ளது</SelectItem>
                    <SelectItem value="inactive">செயலற்றது</SelectItem>
                    <SelectItem value="pending">நிலுவையில் உள்ளது</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="வரிசைப்படுத்து" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="registeredDate">பதிவு தேதி</SelectItem>
                    <SelectItem value="name">பெயர்</SelectItem>
                    <SelectItem value="email">மின்னஞ்சல்</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">ID</TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "name") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("name")
                          setSortOrder("asc")
                        }
                      }}
                    >
                      பெயர்
                      {sortBy === "name" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "email") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("email")
                          setSortOrder("asc")
                        }
                      }}
                    >
                      மின்னஞ்சல்
                      {sortBy === "email" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead>பங்கு</TableHead>
                  <TableHead>மாவட்டம்</TableHead>
                  <TableHead>KYC நிலை</TableHead>
                  <TableHead>நிலை</TableHead>
                  <TableHead>
                    <div
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (sortBy === "registeredDate") {
                          setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                        } else {
                          setSortBy("registeredDate")
                          setSortOrder("desc")
                        }
                      }}
                    >
                      பதிவு தேதி
                      {sortBy === "registeredDate" && <ArrowUpDown className="ml-2 h-4 w-4" />}
                    </div>
                  </TableHead>
                  <TableHead className="text-right">செயல்கள்</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedUsers.length > 0 ? (
                  paginatedUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.id}</TableCell>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {user.role === "reporter" ? "செய்தியாளர்" : user.role === "organizer" ? "அமைப்பாளர்" : "நிர்வாகி"}
                        </Badge>
                      </TableCell>
                      <TableCell>{user.district}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            user.kycStatus === "verified"
                              ? "default"
                              : user.kycStatus === "pending"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {user.kycStatus === "verified"
                            ? "சரிபார்க்கப்பட்டது"
                            : user.kycStatus === "pending"
                              ? "நிலுவையில் உள்ளது"
                              : "நிராகரிக்கப்பட்டது"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            user.status === "active" ? "default" : user.status === "pending" ? "secondary" : "outline"
                          }
                        >
                          {user.status === "active"
                            ? "செயலில் உள்ளது"
                            : user.status === "pending"
                              ? "நிலுவையில் உள்ளது"
                              : "செயலற்றது"}
                        </Badge>
                      </TableCell>
                      <TableCell>{user.registeredDate}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(user.id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-4">
                      பயனர்கள் எதுவும் கிடைக்கவில்லை
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {totalPages > 1 && (
          <div className="flex justify-center mt-4">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span>
                {currentPage} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
