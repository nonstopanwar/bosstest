"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Newspaper, Calendar, Users, DollarSign, LogOut, PlusCircle, FileText, Settings } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import AdminHeader from "@/components/admin/admin-header"

export default function AdminDashboardPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [adminData, setAdminData] = useState<{ email: string; role: string } | null>(null)

  useEffect(() => {
    try {
      const data = localStorage.getItem("karuppu_admin")
      if (data) {
        setAdminData(JSON.parse(data))
      }
    } catch (error) {
      console.error("Error loading admin data:", error)
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("karuppu_admin")
    toast({
      title: "வெற்றி!",
      description: "வெற்றிகரமாக வெளியேறினீர்கள்.",
    })
    router.push("/admin/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader adminEmail={adminData?.email} onLogout={handleLogout} />

      <main className="container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">நிர்வாக டாஷ்போர்டு</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Newspaper className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">மொத்த செய்திகள்</p>
                <p className="text-2xl font-bold">24</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">மொத்த நிகழ்வுகள்</p>
                <p className="text-2xl font-bold">12</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">மொத்த பயனர்கள்</p>
                <p className="text-2xl font-bold">156</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">மொத்த நன்கொடைகள்</p>
                <p className="text-2xl font-bold">₹45,000</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Tabs defaultValue="news">
              <TabsList className="mb-4">
                <TabsTrigger value="news">செய்திகள்</TabsTrigger>
                <TabsTrigger value="events">நிகழ்வுகள்</TabsTrigger>
              </TabsList>

              <TabsContent value="news" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold">சமீபத்திய செய்திகள்</h2>
                  <Link href="/admin/news/create">
                    <Button className="bg-primary hover:bg-primary/90">
                      <PlusCircle className="mr-2 h-4 w-4" />
                      புதிய செய்தி
                    </Button>
                  </Link>
                </div>

                <Card>
                  <CardContent className="p-0">
                    <div className="divide-y">
                      <div className="flex items-center justify-between p-4">
                        <div>
                          <p className="font-medium">
                            பல சிறுமிகளின் | பெண்களின் வாழ்வை இன்ஸ்டாகிராம் மூலம் சீரழித்த காமக் கொடூரனை கைது செய்யாமல் விட்ட காவல்துறை
                          </p>
                          <p className="text-sm text-muted-foreground">2025-05-10</p>
                        </div>
                        <div className="flex gap-2">
                          <Link href="/admin/news/edit/1">
                            <Button variant="outline" size="sm">
                              திருத்த
                            </Button>
                          </Link>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4">
                        <div>
                          <p className="font-medium">ஊழல் தடுப்பு நடவடிக்கைகள் குறித்த விழிப்புணர்வு கருத்தரங்கம்</p>
                          <p className="text-sm text-muted-foreground">2025-05-08</p>
                        </div>
                        <div className="flex gap-2">
                          <Link href="/admin/news/edit/2">
                            <Button variant="outline" size="sm">
                              திருத்த
                            </Button>
                          </Link>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4">
                        <div>
                          <p className="font-medium">ஊழல் புகார் எண் அறிமுகம்: 24 மணி நேரமும் செயல்படும்</p>
                          <p className="text-sm text-muted-foreground">2025-05-05</p>
                        </div>
                        <div className="flex gap-2">
                          <Link href="/admin/news/edit/3">
                            <Button variant="outline" size="sm">
                              திருத்த
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-center">
                  <Link href="/admin/news">
                    <Button variant="link">அனைத்து செய்திகளையும் காண</Button>
                  </Link>
                </div>
              </TabsContent>

              <TabsContent value="events" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold">சமீபத்திய நிகழ்வுகள்</h2>
                  <Link href="/admin/events/create">
                    <Button className="bg-primary hover:bg-primary/90">
                      <PlusCircle className="mr-2 h-4 w-4" />
                      புதிய நிகழ்வு
                    </Button>
                  </Link>
                </div>

                <Card>
                  <CardContent className="p-0">
                    <div className="divide-y">
                      <div className="flex items-center justify-between p-4">
                        <div>
                          <p className="font-medium">
                            தேர்தலை பணம் கொடுக்காமல் நடத்தவும் வாக்களிக்க பணம் பெறுவது குற்றமெனவும் விழிப்புணர்வு பிரசாரம்
                          </p>
                          <p className="text-sm text-muted-foreground">2025-05-15</p>
                        </div>
                        <div className="flex gap-2">
                          <Link href="/admin/events/edit/6">
                            <Button variant="outline" size="sm">
                              திருத்த
                            </Button>
                          </Link>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4">
                        <div>
                          <p className="font-medium">இரத்த தான முகாம் மற்றும் மருத்துவ முகாம்</p>
                          <p className="text-sm text-muted-foreground">2025-04-15</p>
                        </div>
                        <div className="flex gap-2">
                          <Link href="/admin/events/edit/1">
                            <Button variant="outline" size="sm">
                              திருத்த
                            </Button>
                          </Link>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4">
                        <div>
                          <p className="font-medium">இலஞ்சம் குறித்த விழிப்புணர்வு - மாணவர்களுக்கான நிகழ்ச்சி</p>
                          <p className="text-sm text-muted-foreground">2025-04-10</p>
                        </div>
                        <div className="flex gap-2">
                          <Link href="/admin/events/edit/2">
                            <Button variant="outline" size="sm">
                              திருத்த
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-center">
                  <Link href="/admin/events">
                    <Button variant="link">அனைத்து நிகழ்வுகளையும் காண</Button>
                  </Link>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>விரைவு செயல்கள்</CardTitle>
                <CardDescription>பொதுவான நிர்வாக செயல்கள்</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link href="/admin/news/create">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    புதிய செய்தி உருவாக்க
                  </Button>
                </Link>

                <Link href="/admin/events/create">
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="mr-2 h-4 w-4" />
                    புதிய நிகழ்வு உருவாக்க
                  </Button>
                </Link>

                <Link href="/admin/users">
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="mr-2 h-4 w-4" />
                    பயனர்களை நிர்வகிக்க
                  </Button>
                </Link>

                <Link href="/admin/settings">
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="mr-2 h-4 w-4" />
                    அமைப்புகள்
                  </Button>
                </Link>

                <Button
                  variant="outline"
                  className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  வெளியேற
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>நிர்வாகி விவரங்கள்</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="bg-primary/10 p-3 rounded-full">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{adminData?.email || "editor@karuppu.in"}</p>
                    <p className="text-sm text-muted-foreground">ஆசிரியர்</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
