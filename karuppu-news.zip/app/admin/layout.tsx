"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Loader2 } from "lucide-react"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const pathname = usePathname()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const checkAuth = () => {
      // Skip auth check for login page
      if (pathname === "/admin/login") {
        setIsLoading(false)
        return
      }

      try {
        const adminData = localStorage.getItem("karuppu_admin")

        if (!adminData) {
          // Not logged in, redirect to login
          router.push("/admin/login")
          return
        }

        const admin = JSON.parse(adminData)

        if (!admin.isLoggedIn) {
          // Not logged in, redirect to login
          router.push("/admin/login")
          return
        }

        // Check if login session is expired (24 hours)
        const loginTime = new Date(admin.loginTime).getTime()
        const currentTime = new Date().getTime()
        const hoursDiff = (currentTime - loginTime) / (1000 * 60 * 60)

        if (hoursDiff > 24) {
          // Session expired, clear and redirect
          localStorage.removeItem("karuppu_admin")
          router.push("/admin/login")
          return
        }

        setIsLoading(false)
      } catch (error) {
        console.error("Auth check error:", error)
        router.push("/admin/login")
      }
    }

    checkAuth()
  }, [pathname, router])

  if (isLoading && pathname !== "/admin/login") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return <>{children}</>
}
