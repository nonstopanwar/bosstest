"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Eye, EyeOff, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/components/ui/use-toast"

export default function LoginPage() {
  const { toast } = useToast()
  const [showPassword, setShowPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState("")
  const [showForgotPassword, setShowForgotPassword] = useState(false)

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword)
  }

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    // Get form data
    const formData = new FormData(e.currentTarget)
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const userType = formData.get("userType") as string

    try {
      // In a real app, this would be an API call to verify credentials
      // For now, we'll simulate a successful login
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "வெற்றி!",
        description: "வெற்றிகரமாக உள்நுழைந்தீர்கள்.",
      })
    } catch (error) {
      console.error("Login error:", error)
      setError("உள்நுழைவதில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    if (!forgotPasswordEmail) {
      setError("மின்னஞ்சல் முகவரியை உள்ளிடவும்")
      setIsSubmitting(false)
      return
    }

    try {
      // In a real app, this would be an API call to send a password reset email
      // For now, we'll simulate a successful request
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "வெற்றி!",
        description: "கடவுச்சொல் மீட்டமைப்பு இணைப்பு அனுப்பப்பட்டது. உங்கள் மின்னஞ்சலைச் சரிபார்க்கவும்.",
      })
      setShowForgotPassword(false)
    } catch (error) {
      console.error("Forgot password error:", error)
      setError("கடவுச்சொல் மீட்டமைப்பு கோரிக்கையில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto flex items-center justify-center min-h-[calc(100vh-300px)] py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 flex flex-col items-center">
          <div className="w-20 h-20 mb-2">
            <Image src="/images/logo.png" alt="Karuppu Logo" width={80} height={80} />
          </div>
          <CardTitle className="text-2xl text-center">உள்நுழைய</CardTitle>
          <CardDescription className="text-center">உங்கள் கணக்கில் உள்நுழைய விவரங்களை உள்ளிடவும்</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {showForgotPassword ? (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="forgot-email">மின்னஞ்சல்</Label>
                <Input
                  id="forgot-email"
                  type="email"
                  placeholder="your@email.com"
                  value={forgotPasswordEmail}
                  onChange={(e) => setForgotPasswordEmail(e.target.value)}
                  required
                />
              </div>
              <div className="flex flex-col space-y-2">
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                  {isSubmitting ? "சமர்ப்பிக்கிறது..." : "மீட்டமைப்பு இணைப்பை அனுப்பு"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => setShowForgotPassword(false)}
                  disabled={isSubmitting}
                >
                  திரும்பிச் செல்ல
                </Button>
              </div>
            </form>
          ) : (
            <Tabs defaultValue="reporter" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="reporter">செய்தியாளர்</TabsTrigger>
                <TabsTrigger value="district-organizer">மாவட்ட அமைப்பாளர்</TabsTrigger>
                <TabsTrigger value="state-organizer">மாநில அமைப்பாளர்</TabsTrigger>
                <TabsTrigger value="member">உறுப்பினர்</TabsTrigger>
              </TabsList>

              {["reporter", "district-organizer", "state-organizer", "member"].map((userType) => (
                <TabsContent key={userType} value={userType} className="space-y-4 mt-4">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <input type="hidden" name="userType" value={userType} />
                    <div className="space-y-2">
                      <Label htmlFor={`${userType}-email`}>மின்னஞ்சல்</Label>
                      <Input id={`${userType}-email`} name="email" type="email" placeholder="your@email.com" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor={`${userType}-password`}>கடவுச்சொல்</Label>
                      <div className="relative">
                        <Input
                          id={`${userType}-password`}
                          name="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          required
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                          onClick={togglePasswordVisibility}
                        >
                          {showPassword ? (
                            <EyeOff className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <Eye className="h-4 w-4 text-muted-foreground" />
                          )}
                          <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={`${userType}-remember`}
                          className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                        />
                        <Label
                          htmlFor={`${userType}-remember`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          என்னை நினைவில் கொள்ள
                        </Label>
                      </div>
                      <Button
                        type="button"
                        variant="link"
                        className="text-sm text-primary p-0 h-auto"
                        onClick={() => setShowForgotPassword(true)}
                      >
                        கடவுச்சொல் மறந்துவிட்டதா?
                      </Button>
                    </div>
                    <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                      {isSubmitting ? "உள்நுழைகிறது..." : "உள்நுழைய"}
                    </Button>
                  </form>
                </TabsContent>
              ))}
            </Tabs>
          )}
        </CardContent>
        <CardFooter className="flex flex-col">
          <div className="text-center text-sm mt-2">
            கணக்கு இல்லையா?{" "}
            <Link href="/register" className="text-primary hover:underline">
              பதிவு செய்ய
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
