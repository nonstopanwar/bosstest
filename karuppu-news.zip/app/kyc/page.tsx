"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { AlertCircle, Upload, Check, Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function KYCPage() {
  const [activeStep, setActiveStep] = useState(1)
  const [progress, setProgress] = useState(25)
  const [uploadedAadhaar, setUploadedAadhaar] = useState(false)
  const [uploadedPan, setUploadedPan] = useState(false)
  const [uploadedSelfie, setUploadedSelfie] = useState(false)

  const handleNext = () => {
    const nextStep = activeStep + 1
    setActiveStep(nextStep)
    setProgress(nextStep * 25)
  }

  const handlePrevious = () => {
    const prevStep = activeStep - 1
    setActiveStep(prevStep)
    setProgress(prevStep * 25)
  }

  const handleAadhaarUpload = () => {
    setUploadedAadhaar(true)
  }

  const handlePanUpload = () => {
    setUploadedPan(true)
  }

  const handleSelfieUpload = () => {
    setUploadedSelfie(true)
  }

  return (
    <div className="container mx-auto py-12">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="space-y-1">
          <div className="flex items-center justify-center mb-4">
            <Image src="/images/logo.png" alt="Karuppu Logo" width={80} height={80} />
          </div>
          <CardTitle className="text-2xl text-center">e-KYC சரிபார்ப்பு</CardTitle>
          <CardDescription className="text-center">உங்கள் அடையாளத்தை சரிபார்க்க கீழே உள்ள படிகளைப் பின்பற்றவும்</CardDescription>
          <Progress value={progress} className="w-full mt-4" />
          <div className="flex justify-between text-sm text-muted-foreground mt-1">
            <span>தொடக்கம்</span>
            <span>ஆவணங்கள்</span>
            <span>சரிபார்ப்பு</span>
            <span>முடிவு</span>
          </div>
        </CardHeader>
        <CardContent>
          {activeStep === 1 && (
            <div className="space-y-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>முக்கிய தகவல்</AlertTitle>
                <AlertDescription>
                  உங்கள் அடையாளத்தை சரிபார்க்க, நாங்கள் உங்கள் ஆதார் மற்றும் பான் கார்டு விவரங்களை சேகரிக்க வேண்டும். உங்கள் தனிப்பட்ட தகவல்கள்
                  பாதுகாப்பாக வைக்கப்படும்.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="aadhaar">ஆதார் எண்</Label>
                  <Input id="aadhaar" placeholder="XXXX XXXX XXXX" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pan">பான் கார்டு எண்</Label>
                  <Input id="pan" placeholder="ABCDE1234F" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dob">பிறந்த தேதி</Label>
                  <Input id="dob" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">பாலினம்</Label>
                  <Select>
                    <SelectTrigger id="gender">
                      <SelectValue placeholder="பாலினத்தைத் தேர்ந்தெடுக்கவும்" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">ஆண்</SelectItem>
                      <SelectItem value="female">பெண்</SelectItem>
                      <SelectItem value="other">மற்றவை</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-start space-x-2">
                  <Checkbox id="consent" />
                  <div className="grid gap-1.5 leading-none">
                    <Label
                      htmlFor="consent"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      சரிபார்ப்பு ஒப்புதல்
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      என் அடையாளத்தை சரிபார்க்க தேவையான ஆவணங்களை சமர்ப்பிக்க நான் ஒப்புக்கொள்கிறேன்.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeStep === 2 && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <Label className="flex items-center gap-2">
                    ஆதார் கார்டு பதிவேற்றம்
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>ஆதார் கார்டின் இரு பக்கங்களையும் ஒரே PDF ஆக பதிவேற்றவும்</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Label>
                  <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center gap-2 hover:bg-muted/50 cursor-pointer transition-colors">
                    {!uploadedAadhaar ? (
                      <>
                        <Upload className="h-8 w-8 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">PDF அல்லது JPG (அதிகபட்சம் 5MB)</p>
                        <Button variant="outline" size="sm" onClick={handleAadhaarUpload}>
                          கோப்பைத் தேர்ந்தெடுக்கவும்
                        </Button>
                      </>
                    ) : (
                      <>
                        <Check className="h-8 w-8 text-green-500" />
                        <p className="text-sm font-medium">aadhaar_card.pdf பதிவேற்றப்பட்டது</p>
                        <Button variant="outline" size="sm" onClick={() => setUploadedAadhaar(false)}>
                          மாற்று
                        </Button>
                      </>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  <Label className="flex items-center gap-2">
                    பான் கார்டு பதிவேற்றம்
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>பான் கார்டின் முன்பக்கத்தை மட்டும் பதிவேற்றவும்</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Label>
                  <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center gap-2 hover:bg-muted/50 cursor-pointer transition-colors">
                    {!uploadedPan ? (
                      <>
                        <Upload className="h-8 w-8 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">PDF அல்லது JPG (அதிகபட்சம் 5MB)</p>
                        <Button variant="outline" size="sm" onClick={handlePanUpload}>
                          கோப்பைத் தேர்ந்தெடுக்கவும்
                        </Button>
                      </>
                    ) : (
                      <>
                        <Check className="h-8 w-8 text-green-500" />
                        <p className="text-sm font-medium">pan_card.pdf பதிவேற்றப்பட்டது</p>
                        <Button variant="outline" size="sm" onClick={() => setUploadedPan(false)}>
                          மாற்று
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <Label className="flex items-center gap-2">
                  சுய புகைப்படம் பதிவேற்றம்
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="h-4 w-4 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>தெளிவான முகத்துடன் சமீபத்திய புகைப்படத்தை பதிவேற்றவும்</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </Label>
                <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center gap-2 hover:bg-muted/50 cursor-pointer transition-colors">
                  {!uploadedSelfie ? (
                    <>
                      <Upload className="h-8 w-8 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">JPG அல்லது PNG (அதிகபட்சம் 2MB)</p>
                      <Button variant="outline" size="sm" onClick={handleSelfieUpload}>
                        கோப்பைத் தேர்ந்தெடுக்கவும்
                      </Button>
                    </>
                  ) : (
                    <>
                      <Check className="h-8 w-8 text-green-500" />
                      <p className="text-sm font-medium">selfie.jpg பதிவேற்றப்பட்டது</p>
                      <Button variant="outline" size="sm" onClick={() => setUploadedSelfie(false)}>
                        மாற்று
                      </Button>
                    </>
                  )}
                </div>
              </div>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>ஆவணங்கள் சரிபார்ப்பு</AlertTitle>
                <AlertDescription>
                  உங்கள் ஆவணங்கள் அனைத்தும் தெளிவாகவும், முழுமையாகவும் இருப்பதை உறுதிசெய்யவும். மங்கலான அல்லது வெட்டப்பட்ட படங்கள்
                  நிராகரிக்கப்படலாம்.
                </AlertDescription>
              </Alert>
            </div>
          )}

          {activeStep === 3 && (
            <div className="space-y-6">
              <Alert className="bg-yellow-50 border-yellow-200">
                <AlertCircle className="h-4 w-4 text-yellow-600" />
                <AlertTitle className="text-yellow-600">சரிபார்ப்பு நிலையில் உள்ளது</AlertTitle>
                <AlertDescription className="text-yellow-700">
                  உங்கள் ஆவணங்கள் தற்போது சரிபார்க்கப்படுகின்றன. இந்த செயல்முறை 24-48 மணி நேரம் எடுக்கலாம்.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">சரிபார்ப்பு நிலை</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>ஆதார் சரிபார்ப்பு</span>
                    <span className="text-yellow-600 bg-yellow-50 px-2 py-1 rounded text-xs">நிலுவையில் உள்ளது</span>
                  </div>
                  <Progress value={30} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>பான் சரிபார்ப்பு</span>
                    <span className="text-yellow-600 bg-yellow-50 px-2 py-1 rounded text-xs">நிலுவையில் உள்ளது</span>
                  </div>
                  <Progress value={30} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>முகம் சரிபார்ப்பு</span>
                    <span className="text-yellow-600 bg-yellow-50 px-2 py-1 rounded text-xs">நிலுவையில் உள்ளது</span>
                  </div>
                  <Progress value={30} className="h-2" />
                </div>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <h3 className="text-lg font-medium mb-2">அடுத்த படிகள்</h3>
                <ul className="space-y-2 list-disc list-inside text-sm">
                  <li>உங்கள் ஆவணங்கள் சரிபார்க்கப்பட்டவுடன், உங்களுக்கு மின்னஞ்சல் மூலம் அறிவிப்பு வரும்.</li>
                  <li>சரிபார்ப்பு வெற்றிகரமாக முடிந்தால், உங்கள் கணக்கு செயல்படுத்தப்படும்.</li>
                  <li>ஏதேனும் சிக்கல் இருந்தால், நாங்கள் உங்களை தொடர்பு கொள்வோம்.</li>
                </ul>
              </div>
            </div>
          )}

          {activeStep === 4 && (
            <div className="space-y-6 text-center">
              <div className="flex justify-center">
                <div className="rounded-full bg-green-100 p-3">
                  <Check className="h-8 w-8 text-green-600" />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium">KYC சமர்ப்பிப்பு வெற்றிகரமானது</h3>
                <p className="text-muted-foreground mt-1">
                  உங்கள் KYC ஆவணங்கள் வெற்றிகரமாக சமர்ப்பிக்கப்பட்டன. சரிபார்ப்பு முடிந்ததும் உங்களுக்கு அறிவிப்போம்.
                </p>
              </div>

              <div className="bg-muted p-4 rounded-lg text-left">
                <h4 className="font-medium mb-2">சமர்ப்பிப்பு விவரங்கள்</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>சமர்ப்பிப்பு ஐடி:</div>
                  <div className="font-medium">KYC78945612</div>
                  <div>சமர்ப்பிக்கப்பட்ட தேதி:</div>
                  <div className="font-medium">{new Date().toLocaleDateString()}</div>
                  <div>மதிப்பீட்டு நேரம்:</div>
                  <div className="font-medium">24-48 மணி நேரம்</div>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">உங்கள் KYC நிலையை பின்வரும் பக்கத்தில் சரிபார்க்கலாம்</p>
                <Button variant="outline" className="mx-auto">
                  KYC நிலையைக் காண
                </Button>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          {activeStep > 1 && (
            <Button variant="outline" onClick={handlePrevious}>
              முந்தைய
            </Button>
          )}
          {activeStep < 4 ? (
            <Button
              className="ml-auto bg-primary hover:bg-primary/90"
              onClick={handleNext}
              disabled={activeStep === 2 && (!uploadedAadhaar || !uploadedPan || !uploadedSelfie)}
            >
              {activeStep === 3 ? "முடிக்க" : "அடுத்து"}
            </Button>
          ) : (
            <Button className="ml-auto bg-primary hover:bg-primary/90">முகப்புக்குச் செல்ல</Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
