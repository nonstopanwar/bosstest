"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Eye, EyeOff, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

// Sample districts for dropdown
const districts = [
  "சென்னை",
  "கோயம்புத்தூர்",
  "மதுரை",
  "திருச்சி",
  "சேலம்",
  "திருநெல்வேலி",
  "தூத்துக்குடி",
  "ஈரோடு",
  "வேலூர்",
  "தஞ்சாவூர்",
  "திண்டுக்கல்",
  "கன்னியாகுமரி",
]

// Blood groups
const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]

export default function RegisterPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formError, setFormError] = useState("")
  const [userType, setUserType] = useState("reporter")
  const [formData, setFormData] = useState({
    reporter: {
      name: "",
      email: "",
      phone: "",
      district: "",
      password: "",
      confirmPassword: "",
      address: "",
      bloodGroup: "",
      willingToDonate: false,
      termsAccepted: false,
    },
    districtOrganizer: {
      name: "",
      email: "",
      phone: "",
      district: "",
      password: "",
      confirmPassword: "",
      address: "",
      experience: "",
      bloodGroup: "",
      willingToDonate: false,
      termsAccepted: false,
    },
    stateOrganizer: {
      name: "",
      email: "",
      phone: "",
      state: "தமிழ்நாடு",
      password: "",
      confirmPassword: "",
      address: "",
      experience: "",
      bloodGroup: "",
      willingToDonate: false,
      termsAccepted: false,
    },
    member: {
      name: "",
      email: "",
      phone: "",
      district: "",
      password: "",
      confirmPassword: "",
      address: "",
      occupation: "",
      bloodGroup: "",
      willingToDonate: false,
      termsAccepted: false,
    },
  })

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword)
  }

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword)
  }

  const handleChange = (
    type: "reporter" | "districtOrganizer" | "stateOrganizer" | "member",
    field: string,
    value: string | boolean,
  ) => {
    setFormData((prev) => ({
      ...prev,
      [type]: {
        ...prev[type],
        [field]: value,
      },
    }))
  }

  const validateForm = (data: any) => {
    if (!data.name || !data.email || !data.phone || !data.password) {
      setFormError("அனைத்து அவசியமான புலங்களையும் நிரப்பவும்")
      return false
    }

    if (data.password !== data.confirmPassword) {
      setFormError("கடவுச்சொற்கள் பொருந்தவில்லை")
      return false
    }

    if (!data.termsAccepted) {
      setFormError("விதிமுறைகள் மற்றும் நிபந்தனைகளை ஏற்க வேண்டும்")
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setFormError("")

    let currentFormData
    switch (userType) {
      case "reporter":
        currentFormData = formData.reporter
        break
      case "district-organizer":
        currentFormData = formData.districtOrganizer
        break
      case "state-organizer":
        currentFormData = formData.stateOrganizer
        break
      case "member":
        currentFormData = formData.member
        break
      default:
        currentFormData = formData.reporter
    }

    if (!validateForm(currentFormData)) {
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, this would be an API call to register the user
      // For now, we'll simulate a successful registration
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "வெற்றி!",
        description: "பதிவு வெற்றிகரமாக முடிந்தது. e-KYC சரிபார்ப்பை நிறைவு செய்யவும்.",
      })

      // Redirect to KYC page
      router.push("/kyc")
    } catch (error) {
      console.error("Registration error:", error)
      setFormError("பதிவு செய்வதில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.")
      toast({
        variant: "destructive",
        title: "பிழை!",
        description: "பதிவு செய்வதில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto py-12">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="space-y-1 flex flex-col items-center">
          <div className="w-20 h-20 mb-2">
            <Image src="/images/logo.png" alt="Karuppu Logo" width={80} height={80} />
          </div>
          <CardTitle className="text-2xl text-center">பதிவு செய்ய</CardTitle>
          <CardDescription className="text-center">கருப்பு எழுத்துக் கழகத்தில் இணைய விவரங்களை உள்ளிடவும்</CardDescription>
        </CardHeader>
        <CardContent>
          {formError && (
            <Alert className="mb-6 bg-red-50 text-red-800 border-red-200">
              <AlertCircle className="h-4 w-4 text-red-800" />
              <AlertDescription>{formError}</AlertDescription>
            </Alert>
          )}

          <Tabs
            defaultValue="reporter"
            className="w-full"
            value={userType}
            onValueChange={(value) => setUserType(value)}
          >
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="reporter">செய்தியாளர்</TabsTrigger>
              <TabsTrigger value="district-organizer">மாவட்ட அமைப்பாளர்</TabsTrigger>
              <TabsTrigger value="state-organizer">மாநில அமைப்பாளர்</TabsTrigger>
              <TabsTrigger value="member">உறுப்பினர்</TabsTrigger>
            </TabsList>

            {/* Reporter Registration Form */}
            <TabsContent value="reporter" className="mt-4">
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="reporter-name">
                      பெயர் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="reporter-name"
                      placeholder="உங்கள் பெயர்"
                      value={formData.reporter.name}
                      onChange={(e) => handleChange("reporter", "name", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reporter-email">
                      மின்னஞ்சல் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="reporter-email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.reporter.email}
                      onChange={(e) => handleChange("reporter", "email", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reporter-phone">
                      தொலைபேசி எண் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="reporter-phone"
                      placeholder="9876543210"
                      value={formData.reporter.phone}
                      onChange={(e) => handleChange("reporter", "phone", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reporter-district">
                      மாவட்டம் <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.reporter.district}
                      onValueChange={(value) => handleChange("reporter", "district", value)}
                    >
                      <SelectTrigger id="reporter-district">
                        <SelectValue placeholder="மாவட்டத்தைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {districts.map((district) => (
                          <SelectItem key={district} value={district}>
                            {district}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reporter-password">
                      கடவுச்சொல் <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="reporter-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={formData.reporter.password}
                        onChange={(e) => handleChange("reporter", "password", e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={togglePasswordVisibility}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reporter-confirm-password">
                      கடவுச்சொல் உறுதிப்படுத்த <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="reporter-confirm-password"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={formData.reporter.confirmPassword}
                        onChange={(e) => handleChange("reporter", "confirmPassword", e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={toggleConfirmPasswordVisibility}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showConfirmPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="reporter-address">முகவரி</Label>
                    <Textarea
                      id="reporter-address"
                      placeholder="உங்கள் முகவரியை உள்ளிடவும்"
                      value={formData.reporter.address}
                      onChange={(e) => handleChange("reporter", "address", e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reporter-blood-group">இரத்த வகை</Label>
                    <Select
                      value={formData.reporter.bloodGroup}
                      onValueChange={(value) => handleChange("reporter", "bloodGroup", value)}
                    >
                      <SelectTrigger id="reporter-blood-group">
                        <SelectValue placeholder="இரத்த வகையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {bloodGroups.map((group) => (
                          <SelectItem key={group} value={group}>
                            {group}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2 pt-4">
                    <Checkbox
                      id="reporter-willing-to-donate"
                      checked={formData.reporter.willingToDonate}
                      onCheckedChange={(checked) => handleChange("reporter", "willingToDonate", !!checked)}
                    />
                    <Label
                      htmlFor="reporter-willing-to-donate"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      இரத்த தானம் செய்ய விருப்பம்
                    </Label>
                  </div>
                </div>

                <div className="flex items-center space-x-2 mt-6">
                  <Checkbox
                    id="reporter-terms"
                    checked={formData.reporter.termsAccepted}
                    onCheckedChange={(checked) => handleChange("reporter", "termsAccepted", !!checked)}
                    required
                  />
                  <Label
                    htmlFor="reporter-terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    <span>
                      நான்{" "}
                      <a href="/terms" className="text-primary hover:underline">
                        விதிமுறைகள் மற்றும் நிபந்தனைகளை
                      </a>{" "}
                      ஏற்கிறேன்
                    </span>
                  </Label>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                    {isSubmitting ? "பதிவு செய்கிறது..." : "பதிவு செய்ய"}
                  </Button>
                </div>
              </form>
            </TabsContent>

            {/* District Organizer Registration Form */}
            <TabsContent value="district-organizer" className="mt-4">
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="district-organizer-name">
                      பெயர் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="district-organizer-name"
                      placeholder="உங்கள் பெயர்"
                      value={formData.districtOrganizer.name}
                      onChange={(e) => handleChange("districtOrganizer", "name", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district-organizer-email">
                      மின்னஞ்சல் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="district-organizer-email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.districtOrganizer.email}
                      onChange={(e) => handleChange("districtOrganizer", "email", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district-organizer-phone">
                      தொலைபேசி எண் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="district-organizer-phone"
                      placeholder="9876543210"
                      value={formData.districtOrganizer.phone}
                      onChange={(e) => handleChange("districtOrganizer", "phone", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district-organizer-district">
                      மாவட்டம் <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.districtOrganizer.district}
                      onValueChange={(value) => handleChange("districtOrganizer", "district", value)}
                    >
                      <SelectTrigger id="district-organizer-district">
                        <SelectValue placeholder="மாவட்டத்தைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {districts.map((district) => (
                          <SelectItem key={district} value={district}>
                            {district}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district-organizer-password">
                      கடவுச்சொல் <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="district-organizer-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={formData.districtOrganizer.password}
                        onChange={(e) => handleChange("districtOrganizer", "password", e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={togglePasswordVisibility}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district-organizer-confirm-password">
                      கடவுச்சொல் உறுதிப்படுத்த <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="district-organizer-confirm-password"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={formData.districtOrganizer.confirmPassword}
                        onChange={(e) => handleChange("districtOrganizer", "confirmPassword", e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={toggleConfirmPasswordVisibility}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showConfirmPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="district-organizer-address">முகவரி</Label>
                    <Textarea
                      id="district-organizer-address"
                      placeholder="உங்கள் முகவரியை உள்ளிடவும்"
                      value={formData.districtOrganizer.address}
                      onChange={(e) => handleChange("districtOrganizer", "address", e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="district-organizer-experience">அனுபவம்</Label>
                    <Textarea
                      id="district-organizer-experience"
                      placeholder="உங்கள் அனுபவத்தை பற்றி சிறிது விவரிக்கவும்"
                      value={formData.districtOrganizer.experience}
                      onChange={(e) => handleChange("districtOrganizer", "experience", e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district-organizer-blood-group">இரத்த வகை</Label>
                    <Select
                      value={formData.districtOrganizer.bloodGroup}
                      onValueChange={(value) => handleChange("districtOrganizer", "bloodGroup", value)}
                    >
                      <SelectTrigger id="district-organizer-blood-group">
                        <SelectValue placeholder="இரத்த வகையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {bloodGroups.map((group) => (
                          <SelectItem key={group} value={group}>
                            {group}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2 pt-4">
                    <Checkbox
                      id="district-organizer-willing-to-donate"
                      checked={formData.districtOrganizer.willingToDonate}
                      onCheckedChange={(checked) => handleChange("districtOrganizer", "willingToDonate", !!checked)}
                    />
                    <Label
                      htmlFor="district-organizer-willing-to-donate"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      இரத்த தானம் செய்ய விருப்பம்
                    </Label>
                  </div>
                </div>

                <div className="flex items-center space-x-2 mt-6">
                  <Checkbox
                    id="district-organizer-terms"
                    checked={formData.districtOrganizer.termsAccepted}
                    onCheckedChange={(checked) => handleChange("districtOrganizer", "termsAccepted", !!checked)}
                    required
                  />
                  <Label
                    htmlFor="district-organizer-terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    <span>
                      நான்{" "}
                      <a href="/terms" className="text-primary hover:underline">
                        விதிமுறைகள் மற்றும் நிபந்தனைகளை
                      </a>{" "}
                      ஏற்கிறேன்
                    </span>
                  </Label>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                    {isSubmitting ? "பதிவு செய்கிறது..." : "பதிவு செய்ய"}
                  </Button>
                </div>
              </form>
            </TabsContent>

            {/* State Organizer Registration Form */}
            <TabsContent value="state-organizer" className="mt-4">
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="state-organizer-name">
                      பெயர் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="state-organizer-name"
                      placeholder="உங்கள் பெயர்"
                      value={formData.stateOrganizer.name}
                      onChange={(e) => handleChange("stateOrganizer", "name", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state-organizer-email">
                      மின்னஞ்சல் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="state-organizer-email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.stateOrganizer.email}
                      onChange={(e) => handleChange("stateOrganizer", "email", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state-organizer-phone">
                      தொலைபேசி எண் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="state-organizer-phone"
                      placeholder="9876543210"
                      value={formData.stateOrganizer.phone}
                      onChange={(e) => handleChange("stateOrganizer", "phone", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state-organizer-state">
                      மாநிலம் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="state-organizer-state"
                      value={formData.stateOrganizer.state}
                      onChange={(e) => handleChange("stateOrganizer", "state", e.target.value)}
                      disabled
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state-organizer-password">
                      கடவுச்சொல் <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="state-organizer-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={formData.stateOrganizer.password}
                        onChange={(e) => handleChange("stateOrganizer", "password", e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={togglePasswordVisibility}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state-organizer-confirm-password">
                      கடவுச்சொல் உறுதிப்படுத்த <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="state-organizer-confirm-password"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={formData.stateOrganizer.confirmPassword}
                        onChange={(e) => handleChange("stateOrganizer", "confirmPassword", e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={toggleConfirmPasswordVisibility}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showConfirmPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="state-organizer-address">முகவரி</Label>
                    <Textarea
                      id="state-organizer-address"
                      placeholder="உங்கள் முகவரியை உள்ளிடவும்"
                      value={formData.stateOrganizer.address}
                      onChange={(e) => handleChange("stateOrganizer", "address", e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="state-organizer-experience">அனுபவம்</Label>
                    <Textarea
                      id="state-organizer-experience"
                      placeholder="உங்கள் அனுபவத்தை பற்றி சிறிது விவரிக்கவும்"
                      value={formData.stateOrganizer.experience}
                      onChange={(e) => handleChange("stateOrganizer", "experience", e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state-organizer-blood-group">இரத்த வகை</Label>
                    <Select
                      value={formData.stateOrganizer.bloodGroup}
                      onValueChange={(value) => handleChange("stateOrganizer", "bloodGroup", value)}
                    >
                      <SelectTrigger id="state-organizer-blood-group">
                        <SelectValue placeholder="இரத்த வகையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {bloodGroups.map((group) => (
                          <SelectItem key={group} value={group}>
                            {group}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2 pt-4">
                    <Checkbox
                      id="state-organizer-willing-to-donate"
                      checked={formData.stateOrganizer.willingToDonate}
                      onCheckedChange={(checked) => handleChange("stateOrganizer", "willingToDonate", !!checked)}
                    />
                    <Label
                      htmlFor="state-organizer-willing-to-donate"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      இரத்த தானம் செய்ய விருப்பம்
                    </Label>
                  </div>
                </div>

                <div className="flex items-center space-x-2 mt-6">
                  <Checkbox
                    id="state-organizer-terms"
                    checked={formData.stateOrganizer.termsAccepted}
                    onCheckedChange={(checked) => handleChange("stateOrganizer", "termsAccepted", !!checked)}
                    required
                  />
                  <Label
                    htmlFor="state-organizer-terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    <span>
                      நான்{" "}
                      <a href="/terms" className="text-primary hover:underline">
                        விதிமுறைகள் மற்றும் நிபந்தனைகளை
                      </a>{" "}
                      ஏற்கிறேன்
                    </span>
                  </Label>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                    {isSubmitting ? "பதிவு செய்கிறது..." : "பதிவு செய்ய"}
                  </Button>
                </div>
              </form>
            </TabsContent>

            {/* Member Registration Form */}
            <TabsContent value="member" className="mt-4">
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="member-name">
                      பெயர் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="member-name"
                      placeholder="உங்கள் பெயர்"
                      value={formData.member.name}
                      onChange={(e) => handleChange("member", "name", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="member-email">
                      மின்னஞ்சல் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="member-email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.member.email}
                      onChange={(e) => handleChange("member", "email", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="member-phone">
                      தொலைபேசி எண் <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="member-phone"
                      placeholder="9876543210"
                      value={formData.member.phone}
                      onChange={(e) => handleChange("member", "phone", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="member-district">
                      மாவட்டம் <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.member.district}
                      onValueChange={(value) => handleChange("member", "district", value)}
                    >
                      <SelectTrigger id="member-district">
                        <SelectValue placeholder="மாவட்டத்தைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {districts.map((district) => (
                          <SelectItem key={district} value={district}>
                            {district}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="member-password">
                      கடவுச்சொல் <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="member-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={formData.member.password}
                        onChange={(e) => handleChange("member", "password", e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={togglePasswordVisibility}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="member-confirm-password">
                      கடவுச்சொல் உறுதிப்படுத்த <span className="text-red-500">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="member-confirm-password"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={formData.member.confirmPassword}
                        onChange={(e) => handleChange("member", "confirmPassword", e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={toggleConfirmPasswordVisibility}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="sr-only">{showConfirmPassword ? "Hide password" : "Show password"}</span>
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="member-address">முகவரி</Label>
                    <Textarea
                      id="member-address"
                      placeholder="உங்கள் முகவரியை உள்ளிடவும்"
                      value={formData.member.address}
                      onChange={(e) => handleChange("member", "address", e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="member-occupation">தொழில்</Label>
                    <Input
                      id="member-occupation"
                      placeholder="உங்கள் தொழில்"
                      value={formData.member.occupation}
                      onChange={(e) => handleChange("member", "occupation", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="member-blood-group">இரத்த வகை</Label>
                    <Select
                      value={formData.member.bloodGroup}
                      onValueChange={(value) => handleChange("member", "bloodGroup", value)}
                    >
                      <SelectTrigger id="member-blood-group">
                        <SelectValue placeholder="இரத்த வகையைத் தேர்ந்தெடுக்கவும்" />
                      </SelectTrigger>
                      <SelectContent>
                        {bloodGroups.map((group) => (
                          <SelectItem key={group} value={group}>
                            {group}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2 pt-4">
                    <Checkbox
                      id="member-willing-to-donate"
                      checked={formData.member.willingToDonate}
                      onCheckedChange={(checked) => handleChange("member", "willingToDonate", !!checked)}
                    />
                    <Label
                      htmlFor="member-willing-to-donate"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      இரத்த தானம் செய்ய விருப்பம்
                    </Label>
                  </div>
                </div>

                <div className="flex items-center space-x-2 mt-6">
                  <Checkbox
                    id="member-terms"
                    checked={formData.member.termsAccepted}
                    onCheckedChange={(checked) => handleChange("member", "termsAccepted", !!checked)}
                    required
                  />
                  <Label
                    htmlFor="member-terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    <span>
                      நான்{" "}
                      <a href="/terms" className="text-primary hover:underline">
                        விதிமுறைகள் மற்றும் நிபந்தனைகளை
                      </a>{" "}
                      ஏற்கிறேன்
                    </span>
                  </Label>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                    {isSubmitting ? "பதிவு செய்கிறது..." : "பதிவு செய்ய"}
                  </Button>
                </div>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
