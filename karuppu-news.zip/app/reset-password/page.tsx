"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Eye, EyeOff, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/components/ui/use-toast"

export default function ResetPasswordPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()

  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [token, setToken] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isTokenValid, setIsTokenValid] = useState(true)

  useEffect(() => {
    const tokenParam = searchParams.get("token")
    const emailParam = searchParams.get("email")

    if (!tokenParam || !emailParam) {
      setIsTokenValid(false)
      setError("செல்லுபடியாகாத அல்லது காலாவதியான மீட்டமைப்பு இணைப்பு.")
      return
    }

    setToken(tokenParam)
    setEmail(emailParam)

    // In a real app, you would validate the token against your database
    // For now, we'll assume it's valid if it exists
  }, [searchParams])

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword)
  }

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!password || !confirmPassword) {
      setError("அனைத்து புலங்களையும் நிரப்பவும்")
      return
    }

    if (password !== confirmPassword) {
      setError("கடவுச்சொற்கள் பொருந்தவில்லை")
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, this would be an API call to reset the password
      // For now, we'll simulate a successful password reset
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "வெற்றி!",
        description: "உங்கள் கடவுச்சொல் வெற்றிகரமாக மீட்டமைக்கப்பட்டது.",
      })

      // Redirect to login page
      router.push("/login")
    } catch (error) {
      console.error("Reset password error:", error)
      setError("கடவுச்சொல் மீட்டமைப்பில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto flex items-center justify-center min-h-[calc(100vh-300px)] py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 flex flex-col items-center">
          <div className="w-20 h-20 mb-2">
            <Image src="/images/logo.png" alt="Karuppu Logo" width={80} height={80} />
          </div>
          <CardTitle className="text-2xl text-center">கடவுச்சொல் மீட்டமைப்பு</CardTitle>
          <CardDescription className="text-center">புதிய கடவுச்சொல்லை உருவாக்கவும்</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {isTokenValid ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">மின்னஞ்சல்</Label>
                <Input id="email" type="email" value={email} disabled />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">புதிய கடவுச்சொல்</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={togglePasswordVisibility}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password">கடவுச்சொல்லை உறுதிப்படுத்தவும்</Label>
                <div className="relative">
                  <Input
                    id="confirm-password"
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={toggleConfirmPasswordVisibility}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className="sr-only">{showConfirmPassword ? "Hide password" : "Show password"}</span>
                  </Button>
                </div>
              </div>

              <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                {isSubmitting ? "சமர்ப்பிக்கிறது..." : "கடவுச்சொல்லை மீட்டமைக்க"}
              </Button>
            </form>
          ) : (
            <div className="text-center py-4">
              <p className="mb-4">செல்லுபடியாகாத அல்லது காலாவதியான மீட்டமைப்பு இணைப்பு.</p>
              <Button onClick={() => router.push("/login")} className="bg-primary hover:bg-primary/90">
                உள்நுழைவு பக்கத்திற்குச் செல்ல
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-muted-foreground">
            உள்நுழைவு பக்கத்திற்குத் திரும்ப{" "}
            <Button variant="link" className="p-0 h-auto text-primary" onClick={() => router.push("/login")}>
              இங்கே கிளிக் செய்யவும்
            </Button>
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}
