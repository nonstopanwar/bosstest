import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function AboutPage() {
  return (
    <div className="container mx-auto py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold mb-4">எங்களைப் பற்றி</h1>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
          கருப்பு எழுத்துக் கழகம் - ஊழலுக்கு எதிரான குரல் கொடுக்கும் தமிழ் செய்தி அமைப்பு
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <Image src="/images/logo.png" alt="Karuppu Logo" width={400} height={400} className="mx-auto" />
        </div>
        <div className="space-y-6">
          <h2 className="text-2xl font-bold">எங்கள் நோக்கம்</h2>
          <p className="text-lg">
            கருப்பு எழுத்துக் கழகம் என்பது ஊழலுக்கு எதிரான குரல் கொடுக்கும் ஒரு தமிழ் செய்தி அமைப்பாகும். நாங்கள் 2016 ஆம் ஆண்டு தொடங்கப்பட்டு,
            ஊழல் குறித்த செய்திகளை வெளிப்படுத்தி, ஊழலுக்கு எதிரான விழிப்புணர்வை ஏற்படுத்தி வருகிறோம்.
          </p>
          <p className="text-lg">
            எங்கள் குறிக்கோள் ஊழலற்ற சமூகத்தை உருவாக்குவதாகும். உண்மையான செய்திகளை வெளிப்படுத்துவதன் மூலம், சமூகத்தில் மாற்றத்தை ஏற்படுத்த நாங்கள்
            உறுதிபூண்டுள்ளோம்.
          </p>
          <div className="flex flex-wrap gap-2 mt-4">
            <Badge className="bg-primary">ஊழலுக்கு எதிரான குரல்</Badge>
            <Badge className="bg-secondary">உண்மையான செய்திகள்</Badge>
            <Badge className="bg-primary">சமூக மாற்றம்</Badge>
            <Badge className="bg-secondary">மக்கள் நலன்</Badge>
          </div>
        </div>
      </div>

      <div className="bg-muted p-8 rounded-lg mb-16">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">எங்கள் கொள்கைகள்</h2>
          <p className="text-muted-foreground">கருப்பு எழுத்துக் கழகத்தின் அடிப்படை கொள்கைகள்</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="bg-primary/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <span className="text-primary text-xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-bold mb-2">உண்மை</h3>
              <p>
                உண்மையான செய்திகளை மட்டுமே வெளியிடுவது எங்கள் முதல் கொள்கை. எந்த செய்தியும் வெளியிடப்படும் முன் அதன் உண்மைத்தன்மை
                சரிபார்க்கப்படும்.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="bg-primary/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <span className="text-primary text-xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-bold mb-2">சுதந்திரம்</h3>
              <p>எந்த அரசியல் கட்சி அல்லது அமைப்பின் தாக்கமும் இல்லாமல் சுதந்திரமாக செயல்படுவது எங்கள் இரண்டாவது கொள்கை.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="bg-primary/10 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <span className="text-primary text-xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-bold mb-2">நேர்மை</h3>
              <p>அனைத்து செய்திகளையும் நேர்மையாகவும், பாரபட்சமின்றியும் வெளியிடுவது எங்கள் மூன்றாவது கொள்கை.</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl font-bold text-center mb-8">எங்கள் வரலாறு</h2>
        <div className="space-y-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="bg-primary text-white p-4 rounded-lg md:w-32 text-center flex-shrink-0">
              <span className="text-xl font-bold">2016</span>
            </div>
            <div className="bg-muted p-6 rounded-lg flex-grow">
              <h3 className="text-xl font-bold mb-2">கருப்பு எழுத்துக் கழகம் தொடக்கம்</h3>
              <p>
                ஊழலுக்கு எதிரான குரல் கொடுக்கும் நோக்கத்துடன் கருப்பு எழுத்துக் கழகம் தொடங்கப்பட்டது. ஆரம்பத்தில் சிறிய அளவில் செயல்பட்டு வந்த
                எங்கள் அமைப்பு, பின்னர் படிப்படியாக வளர்ந்தது.
              </p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="bg-primary text-white p-4 rounded-lg md:w-32 text-center flex-shrink-0">
              <span className="text-xl font-bold">2018</span>
            </div>
            <div className="bg-muted p-6 rounded-lg flex-grow">
              <h3 className="text-xl font-bold mb-2">முதல் பெரிய வெளிப்படுத்தல்</h3>
              <p>
                ஒரு பெரிய ஊழல் விவகாரத்தை வெளிப்படுத்தியதன் மூலம் கருப்பு எழுத்துக் கழகம் பெரும் கவனத்தைப் பெற்றது. இது எங்கள் அமைப்பின்
                வளர்ச்சிக்கு ஒரு முக்கிய மைல்கல்லாக அமைந்தது.
              </p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="bg-primary text-white p-4 rounded-lg md:w-32 text-center flex-shrink-0">
              <span className="text-xl font-bold">2020</span>
            </div>
            <div className="bg-muted p-6 rounded-lg flex-grow">
              <h3 className="text-xl font-bold mb-2">இணையதள தொடக்கம்</h3>
              <p>
                எங்கள் செய்திகளை மேலும் பரவலாக வழங்கும் நோக்கில் karuppu.in என்ற இணையதளம் தொடங்கப்பட்டது. இதன் மூலம் எங்கள் செய்திகள் மேலும்
                பலரை சென்றடைய ஆரம்பித்தன.
              </p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="bg-primary text-white p-4 rounded-lg md:w-32 text-center flex-shrink-0">
              <span className="text-xl font-bold">2023</span>
            </div>
            <div className="bg-muted p-6 rounded-lg flex-grow">
              <h3 className="text-xl font-bold mb-2">மாவட்ட அளவில் விரிவாக்கம்</h3>
              <p>
                தமிழகத்தின் பல மாவட்டங்களில் எங்கள் செய்தியாளர்கள் மற்றும் அமைப்பாளர்கள் நியமிக்கப்பட்டனர். இதன் மூலம் அனைத்து மாவட்டங்களிலும் நடக்கும்
                ஊழல் சம்பவங்களை வெளிப்படுத்த முடிந்தது.
              </p>
            </div>
          </div>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="bg-primary text-white p-4 rounded-lg md:w-32 text-center flex-shrink-0">
              <span className="text-xl font-bold">2025</span>
            </div>
            <div className="bg-muted p-6 rounded-lg flex-grow">
              <h3 className="text-xl font-bold mb-2">புதிய இணையதள மேம்பாடு</h3>
              <p>
                மேம்படுத்தப்பட்ட புதிய இணையதளம் அறிமுகம் செய்யப்பட்டது. இதன் மூலம் பயனர்கள் எளிதாக செய்திகளை அணுகவும், ஊழல் குறித்த
                புகார்களை அளிக்கவும் முடியும்.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-secondary text-white p-8 rounded-lg">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">எங்கள் குழு</h2>
          <p className="text-gray-300">கருப்பு எழுத்துக் கழகத்தின் முக்கிய உறுப்பினர்கள்</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="relative w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden">
              <Image src="/images/anwar.png" alt="K.S. Anwar" fill className="object-cover" />
            </div>
            <h3 className="text-xl font-bold">கே. எஸ். அன்வர்</h3>
            <p className="text-gray-300">நிறுவனர் & தலைமை ஆசிரியர்</p>
          </div>
          <div className="text-center">
            <div className="relative w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden">
              <Image src="/images/selvaraj.png" alt="Selvaraj. A" fill className="object-cover" />
            </div>
            <h3 className="text-xl font-bold">செல்வராஜ் . ஆ</h3>
            <p className="text-gray-300">பொருளாளர்</p>
          </div>
          <div className="text-center">
            <div className="relative w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden">
              <Image src="/diverse-group.png" alt="Stephen Raj" fill className="object-cover" />
            </div>
            <h3 className="text-xl font-bold">ஸ்டீபன் ராஜ்</h3>
            <p className="text-gray-300">செயலாளர்</p>
          </div>
        </div>
      </div>
    </div>
  )
}
