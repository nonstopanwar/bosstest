import Image from "next/image"
import Link from "next/link"
import { CalendarDays, MapPin, ArrowRight } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Event data
const events = [
  {
    id: 6,
    title: "தேர்தலை பணம் கொடுக்காமல் நடத்தவும் வாக்களிக்க பணம் பெறுவது குற்றமெனவும் விழிப்புணர்வு பிரசாரம்",
    description:
      "கருப்பு எழுத்துக் கழகம் சார்பில் தேர்தலை பணம் கொடுக்காமல் நடத்தவும் வாக்களிக்க பணம் பெறுவது குற்றமெனவும் விழிப்புணர்வு பிரசாரம் மேற்கொள்ளபட்டது. இந்த பிரசாரத்தில் பொதுமக்களுக்கு தேர்தல் நேர்மையின் முக்கியத்துவம் குறித்து விளக்கப்பட்டது.",
    date: "2025-05-15",
    location: "சென்னை கடற்கரை, தமிழ்நாடு",
    category: "விழிப்புணர்வு",
    images: ["/events/election-awareness-1.jpeg", "/events/election-awareness-2.jpeg"],
    featured: true,
  },
  {
    id: 1,
    title: "இரத்த தான முகாம் மற்றும் மருத்துவ முகாம்",
    description:
      "கருப்பு எழுத்துக் கழகம் சார்பில் இரத்த தான முகாம் மற்றும் மருத்துவ முகாம் நடத்தப்பட்டது. இந்த முகாமில் பலர் இரத்த தானம் செய்தனர் மற்றும் இலவச மருத்துவ பரிசோதனை பெற்றனர்.",
    date: "2025-04-15",
    location: "சென்னை, தமிழ்நாடு",
    category: "சமூக சேவை",
    images: [
      "/events/blood-donation-camp.jpeg",
      "/events/blood-donation-volunteers.jpeg",
      "/events/registration-desk.jpeg",
      "/events/medical-checkup.jpeg",
    ],
    featured: true,
  },
  {
    id: 3,
    title: "தமிழக இலஞ்ச ஒழிப்புதுறை குறித்த விவாதம்",
    description:
      "தமிழக இலஞ்ச ஒழிப்புதுறை அரசியல் கட்சிகளிடமிருந்து விலகி சுதந்திரமாக செயல்படுகிறதா என்கிற கேள்வியை மாண்புமிகு உயர்நீதிமன்றம் எழுப்பியும், DVAC எப்போதுமே ஆளும் கட்சிகளுக்கு ஜால்ரா அடிக்கும் பணியை கைவிட்டபாடில்லை போல. ஆளும் கட்சி மற்றும் காவல்துறைகக்கு எதிராக கொடுக்கப்படும் எந்த புகார்களுக்கும் நடவடிக்கை இல்லை. மேதகு உச்ச நீதிமன்றம் உத்தரவிட்டால் மட்டுமே கீழ் படியுமோ தமிழக இலஞ்ச ஒழிப்புத்துறை?",
    date: "2025-05-05",
    location: "சென்னை, தமிழ்நாடு",
    category: "விவாதம்",
    images: ["/anti-corruption-event.png"],
    featured: false,
  },
  {
    id: 4,
    title: "ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி",
    description:
      "கருப்பு எழுத்துக் கழகம் சார்பில் ஊழல் ஒழிப்பு விழிப்புணர்வு பேரணி நடத்தப்பட்டது. இந்த பேரணியில் பல்வேறு சமூக அமைப்புகள் மற்றும் பொதுமக்கள் கலந்து கொண்டனர்.",
    date: "2025-03-28",
    location: "மதுரை, தமிழ்நாடு",
    category: "பேரணி",
    images: ["/anti-corruption-rally.png"],
    featured: false,
  },
  {
    id: 5,
    title: "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல்",
    description:
      "ஊழல் தடுப்பு சட்டங்கள் குறித்த கலந்துரையாடல் நிகழ்ச்சி நடைபெற்றது. இந்த நிகழ்ச்சியில் சட்ட வல்லுநர்கள் மற்றும் அரசு அதிகாரிகள் கலந்து கொண்டனர்.",
    date: "2025-03-15",
    location: "கோயம்புத்தூர், தமிழ்நாடு",
    category: "கலந்துரையாடல்",
    images: ["/legal-discussion.png"],
    featured: false,
  },
]

// Categories
const categories = [
  { value: "all", label: "அனைத்தும்" },
  { value: "சமூக சேவை", label: "சமூக சேவை" },
  { value: "விழிப்புணர்வு", label: "விழிப்புணர்வு" },
  { value: "விவாதம்", label: "விவாதம்" },
  { value: "பேரணி", label: "பேரணி" },
  { value: "கலந்துரையாடல்", label: "கலந்துரையாடல்" },
]

export default function EventsPage() {
  return (
    <div className="container mx-auto py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold mb-4">நிகழ்வுகள்</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          கருப்பு எழுத்துக் கழகத்தின் அனைத்து நிகழ்வுகளையும் இங்கே காணலாம்
        </p>
      </div>

      {/* Featured Events */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">சிறப்பு நிகழ்வுகள்</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {events
            .filter((event) => event.featured)
            .map((event) => (
              <Card key={event.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-64">
                  <Image src={event.images[0] || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
                  <Badge className="absolute top-2 right-2 bg-primary">{event.category}</Badge>
                </div>
                <CardHeader className="p-4">
                  <CardTitle className="text-xl">{event.title}</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <CardDescription className="line-clamp-3 mb-4">{event.description}</CardDescription>
                  <div className="flex items-center text-sm text-muted-foreground gap-4">
                    <div className="flex items-center">
                      <CalendarDays className="mr-1 h-4 w-4" />
                      {new Date(event.date).toLocaleDateString("ta-IN", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </div>
                    <div className="flex items-center">
                      <MapPin className="mr-1 h-4 w-4" />
                      {event.location}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Link href={`/events/${event.id}`}>
                    <Button variant="link" className="p-0 text-primary">
                      மேலும் படிக்க <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
        </div>
      </div>

      {/* All Events */}
      <div>
        <h2 className="text-2xl font-bold mb-6">அனைத்து நிகழ்வுகள்</h2>
        <Tabs defaultValue="all" className="mb-8">
          <TabsList className="flex flex-wrap justify-center mb-6">
            {categories.map((category) => (
              <TabsTrigger key={category.value} value={category.value}>
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((category) => (
            <TabsContent key={category.value} value={category.value}>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {events
                  .filter((event) => category.value === "all" || event.category === category.value)
                  .map((event) => (
                    <Card key={event.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="relative h-48">
                        <Image
                          src={event.images[0] || "/placeholder.svg"}
                          alt={event.title}
                          fill
                          className="object-cover"
                        />
                        <Badge className="absolute top-2 right-2 bg-primary">{event.category}</Badge>
                      </div>
                      <CardHeader className="p-4">
                        <CardTitle className="text-xl line-clamp-2">{event.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 pt-0">
                        <CardDescription className="line-clamp-3 mb-4">{event.description}</CardDescription>
                        <div className="flex items-center text-sm text-muted-foreground gap-4">
                          <div className="flex items-center">
                            <CalendarDays className="mr-1 h-4 w-4" />
                            {new Date(event.date).toLocaleDateString("ta-IN", {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })}
                          </div>
                          <div className="flex items-center">
                            <MapPin className="mr-1 h-4 w-4" />
                            {event.location}
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="p-4 pt-0">
                        <Link href={`/events/${event.id}`}>
                          <Button variant="link" className="p-0 text-primary">
                            மேலும் படிக்க <ArrowRight className="ml-1 h-4 w-4" />
                          </Button>
                        </Link>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  )
}
