"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

const navigation = [
  { name: "முகப்பு", href: "/" },
  { name: "செய்திகள்", href: "/news" },
  { name: "நிகழ்வுகள்", href: "/events" },
  { name: "எங்களைப் பற்றி", href: "/about" },
  { name: "தொடர்பு", href: "/contact" },
  { name: "நன்கொடை", href: "/donate" },
]

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()

  return (
    <header className="bg-secondary text-white">
      <div className="container mx-auto">
        <div className="flex justify-center">
          <Image
            src="/images/banner.png"
            alt="Karuppu Banner"
            width={1000}
            height={150}
            className="w-full max-h-24 object-contain"
          />
        </div>
        <nav className="flex items-center justify-between p-4">
          <div className="flex lg:hidden">
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="bg-secondary text-white">
                <div className="flex flex-col gap-4 mt-8">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={cn(
                        "text-lg font-medium transition-colors hover:text-primary",
                        pathname === item.href ? "text-primary" : "",
                      )}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                  ))}
                  <div className="flex flex-col gap-2 mt-4">
                    <Link href="/login">
                      <Button variant="outline" className="w-full">
                        உள்நுழைய
                      </Button>
                    </Link>
                    <Link href="/register">
                      <Button className="w-full bg-primary hover:bg-primary/90">பதிவு செய்ய</Button>
                    </Link>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          <div className="hidden lg:flex lg:gap-x-8">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "text-base font-medium transition-colors hover:text-primary",
                  pathname === item.href ? "text-primary" : "",
                )}
              >
                {item.name}
              </Link>
            ))}
          </div>

          <div className="hidden lg:flex lg:gap-x-4">
            <Link href="/login">
              <Button variant="outline" className="text-white border-white hover:bg-white hover:text-secondary">
                உள்நுழைய
              </Button>
            </Link>
            <Link href="/register">
              <Button className="bg-primary hover:bg-primary/90">பதிவு செய்ய</Button>
            </Link>
          </div>
        </nav>
      </div>
    </header>
  )
}
