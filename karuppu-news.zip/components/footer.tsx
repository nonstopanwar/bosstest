import Link from "next/link"
import Image from "next/image"
import { Facebook, Twitter, Instagram, Mail, Phone } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-secondary text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col items-center md:items-start">
            <Image src="/images/logo.png" alt="Karuppu Logo" width={150} height={150} className="mb-4" />
            <p className="text-sm text-center md:text-left">கருப்பு எழுத்துக் கழகம் - ஊழலை ஒழிப்போம்! தேசத்தை நேசிப்போம்!</p>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4 text-center md:text-left">தொடர்புக்கு</h3>
            <ul className="space-y-2 text-center md:text-left">
              <li className="flex items-center justify-center md:justify-start gap-2">
                <Mail className="h-4 w-4" />
                <a href="mailto:hello@karuppu.in">hello@karuppu.in</a>
              </li>
              <li className="flex items-center justify-center md:justify-start gap-2">
                <Phone className="h-4 w-4" />
                <span>+91 7826994499</span>
              </li>
            </ul>

            <div className="flex justify-center md:justify-start gap-4 mt-4">
              <a
                href="https://x.com/karuppuTv"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="https://www.facebook.com/karuppuezhutthu"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://www.instagram.com/karuppunews"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4 text-center md:text-left">பயனுள்ள இணைப்புகள்</h3>
            <ul className="space-y-2 text-center md:text-left">
              <li>
                <Link href="/about" className="hover:text-primary">
                  எங்களைப் பற்றி
                </Link>
              </li>
              <li>
                <Link href="/privacy-policy" className="hover:text-primary">
                  தனியுரிமைக் கொள்கை
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-primary">
                  விதிமுறைகள் & நிபந்தனைகள்
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-primary">
                  தொடர்பு கொள்ள
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-4 text-center">
          <p className="text-sm">
            &copy; {new Date().getFullYear()} கருப்பு எழுத்துக் கழகம் - அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை
          </p>
        </div>
      </div>
    </footer>
  )
}
