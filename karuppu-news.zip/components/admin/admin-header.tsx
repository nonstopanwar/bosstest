"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { LogOut, Menu } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useState } from "react"

interface AdminHeaderProps {
  adminEmail?: string
  onLogout: () => void
}

export default function AdminHeader({ adminEmail, onLogout }: AdminHeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const navigation = [
    { name: "டாஷ்போர்டு", href: "/admin/dashboard" },
    { name: "செய்திகள்", href: "/admin/news" },
    { name: "நிகழ்வுகள்", href: "/admin/events" },
    { name: "பயனர்கள்", href: "/admin/users" },
    { name: "அமைப்புகள்", href: "/admin/settings" },
  ]

  return (
    <header className="bg-secondary text-white">
      <div className="container mx-auto">
        <nav className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4">
            <Link href="/admin/dashboard" className="flex items-center gap-2">
              <Image src="/images/logo.png" alt="Karuppu Logo" width={40} height={40} />
              <span className="font-bold text-lg">கருப்பு நிர்வாகம்</span>
            </Link>

            <div className="hidden md:flex md:gap-x-6 ml-6">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="text-sm font-medium transition-colors hover:text-primary"
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:block">
              <span className="text-sm">{adminEmail || "editor@karuppu.in"}</span>
            </div>

            <Button variant="ghost" size="icon" className="text-white hidden md:flex" onClick={onLogout}>
              <LogOut className="h-5 w-5" />
              <span className="sr-only">வெளியேற</span>
            </Button>

            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">மெனு</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="bg-secondary text-white">
                <div className="flex flex-col gap-4 mt-8">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className="text-lg font-medium transition-colors hover:text-primary"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                  ))}
                  <Button
                    variant="ghost"
                    className="justify-start text-white hover:text-primary mt-4"
                    onClick={() => {
                      setIsMenuOpen(false)
                      onLogout()
                    }}
                  >
                    <LogOut className="mr-2 h-5 w-5" />
                    வெளியேற
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </nav>
      </div>
    </header>
  )
}
